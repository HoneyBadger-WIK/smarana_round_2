# SMARANA — Free public deployment

This version is prepared for a **₹0 demo deployment on Render Free**.

## One-click-ish setup
1. Push this repository to GitHub.
2. Open https://render.com and sign in with GitHub.
3. Click **New → Blueprint**.
4. Select your Smarana GitHub repository.
5. Render detects `render.yaml` and creates the free web service.
6. Wait for the first build to finish.
7. Open the generated `https://smarana-....onrender.com` URL and share it with your friend.

The frontend and FastAPI backend are intentionally deployed as **one service**, so there is only one URL and no CORS configuration or paid database is required for the demo.

## Important free-tier limitation
Render Free web services sleep after 15 minutes without traffic and wake up when someone visits again. The local SQLite database is also ephemeral, so this setup is suitable for a hackathon/demo, not production data. Do not put real patient/medical information into this demo.
