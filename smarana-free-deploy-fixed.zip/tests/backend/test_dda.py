"""
SMARANA Backend Unit Tests — DDA Engine & ML Inference
Tests deterministic CPI calculation, difficulty transition rules, and safety constraints.
"""

import pytest
from app.services.dda_engine import evaluate_session, DDAResult
from ml.inference.predict_dda import dda_inference_engine


def test_dda_high_performance_increase():
    """Test that consistently high performance triggers a difficulty increase recommendation."""
    result = evaluate_session(
        accuracy=95.0,
        reaction_time_ms=1200.0,
        memory_score=90.0,
        attention_span_sec=60.0,
        recall_score=95.0,
        error_count=0,
        attempts=1,
        current_difficulty=2,
    )
    assert isinstance(result, DDAResult)
    assert result.cpi_score >= 80.0
    assert result.recommended_difficulty == 3
    assert result.direction == "increase"
    assert "engagement" in result.reason.lower() or "challenge" in result.reason.lower()


def test_dda_low_performance_decrease():
    """Test that low performance triggers a difficulty reduction recommendation for gentle support."""
    result = evaluate_session(
        accuracy=30.0,
        reaction_time_ms=4500.0,
        memory_score=25.0,
        attention_span_sec=15.0,
        recall_score=20.0,
        error_count=6,
        attempts=3,
        current_difficulty=3,
    )
    assert result.cpi_score < 40.0
    assert result.recommended_difficulty == 2
    assert result.direction == "decrease"
    assert "adjusting" in result.reason.lower() or "support" in result.reason.lower()


def test_dda_boundary_caps():
    """Test that difficulty never exceeds maximum cap (5) or goes below minimum (1)."""
    # Max bound test
    max_res = evaluate_session(
        accuracy=100.0,
        reaction_time_ms=800.0,
        memory_score=100.0,
        attention_span_sec=120.0,
        recall_score=100.0,
        error_count=0,
        attempts=1,
        current_difficulty=5,
        max_difficulty=5,
    )
    assert max_res.recommended_difficulty == 5

    # Min bound test
    min_res = evaluate_session(
        accuracy=10.0,
        reaction_time_ms=5000.0,
        memory_score=10.0,
        attention_span_sec=10.0,
        recall_score=10.0,
        error_count=8,
        attempts=3,
        current_difficulty=1,
        min_difficulty=1,
    )
    assert min_res.recommended_difficulty == 1


def test_ml_dda_inference_fallback():
    """Test ML DDA inference engine runs and returns structured DDAResult."""
    result = dda_inference_engine.predict(
        accuracy=88.0,
        reaction_time_ms=1500.0,
        memory_score=85.0,
        attention_span_sec=50.0,
        recall_score=80.0,
        error_count=1,
        attempts=1,
        current_difficulty=2,
    )
    assert isinstance(result, DDAResult)
    assert 1 <= result.recommended_difficulty <= 5
    assert result.cpi_score > 0
