"""
SMARANA Backend Integration Tests — Dashboard & Medical Safety Constraints
Verifies non-diagnostic framing and caregiver data access.
"""

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_root_medical_safety_notice():
    """Verify medical safety disclaimer is included in root response."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert "medical_safety_notice" in data
    assert "diagnostic" in data["medical_safety_notice"].lower()
