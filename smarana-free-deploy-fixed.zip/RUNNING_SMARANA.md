# SMARANA — Local Run Guide

This repository contains:
- `web-dashboard/` — React + Vite dashboard
- `backend/` — FastAPI API + SQLite database
- `ml/` — bundled DDA model and data

## 1. Backend

### Windows PowerShell
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r backend\requirements.txt
$env:PYTHONPATH="backend"
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

### Windows CMD
```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r backend\requirements.txt
set PYTHONPATH=backend
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Backend checks:
- http://127.0.0.1:8000/
- http://127.0.0.1:8000/api/health
- http://127.0.0.1:8000/docs

## 2. Frontend

Open a second terminal:

```powershell
cd web-dashboard
npm install
npm run dev
```

Open:
- http://localhost:3000

Vite proxies `/api` and `/ws` to the backend on port 8000.

## Demo account

The backend seeds these development accounts automatically:

- Elder: `elder@smarana.in` / `password123`
- Caregiver: `caregiver@smarana.in` / `password123`
- Doctor: `doctor@smarana.in` / `password123`

## What was fixed

The original backend authentication imported `python-jose`, `passlib`, and `bcrypt`, which made a clean setup fail when those native/legacy packages were unavailable. Authentication now uses PyJWT and Argon2 (`argon2-cffi`), which are declared directly in `backend/requirements.txt`.

The frontend was also verified with a successful TypeScript + Vite production build.
