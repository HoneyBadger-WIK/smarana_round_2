"""
SMARANA ML — Adaptive Difficulty Adjustment (DDA) Model Training Script
Trains a Random Forest classifier to predict optimal game difficulty levels
based on cognitive performance metrics and session statistics.
"""

import os
import joblib
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

MODEL_OUTPUT_DIR = "/home/harshithkashyap/Desktop/sih 2026/smarana/ml/models"


def generate_synthetic_session_data(n_samples: int = 2000):
    """
    Generate synthetic session performance data consistent with DDA engine logic
    to complement real research dataset features.
    """
    np.random.seed(42)
    
    accuracy = np.random.uniform(20.0, 100.0, n_samples)
    reaction_time = np.random.uniform(500.0, 5000.0, n_samples)
    memory_score = np.random.uniform(10.0, 100.0, n_samples)
    attention_span = np.random.uniform(10.0, 120.0, n_samples)
    recall_score = np.random.uniform(10.0, 100.0, n_samples)
    errors = np.random.randint(0, 10, n_samples)
    attempts = np.random.randint(1, 4, n_samples)
    current_diff = np.random.randint(1, 6, n_samples)

    # Compute Composite Performance Index (CPI)
    norm_reaction = np.clip(100.0 - (reaction_time / 50.0), 0.0, 100.0)
    norm_attention = np.clip((attention_span / 120.0) * 100.0, 0.0, 100.0)
    
    cpi = (
        0.30 * accuracy +
        0.25 * memory_score +
        0.20 * recall_score +
        0.15 * norm_attention +
        0.10 * norm_reaction
    )

    # Determine recommended difficulty shift
    recommended_diff = current_diff.copy()
    for i in range(n_samples):
        score = cpi[i]
        curr = current_diff[i]
        if score >= 80 and curr < 5:
            recommended_diff[i] = curr + 1
        elif score < 40 and curr > 1:
            recommended_diff[i] = curr - 1
        else:
            recommended_diff[i] = curr

    df = pd.DataFrame({
        "accuracy_percentage": accuracy,
        "reaction_time_ms": reaction_time,
        "memory_score": memory_score,
        "attention_span_sec": attention_span,
        "recall_score": recall_score,
        "error_count": errors,
        "attempts": attempts,
        "current_difficulty": current_diff,
        "recommended_difficulty": recommended_diff,
    })
    return df


def train_dda_model():
    """Train Random Forest model and export to joblib."""
    print("Generating training dataset for DDA Engine...")
    df = generate_synthetic_session_data(n_samples=3000)

    feature_cols = [
        "accuracy_percentage",
        "reaction_time_ms",
        "memory_score",
        "attention_span_sec",
        "recall_score",
        "error_count",
        "attempts",
        "current_difficulty",
    ]
    target_col = "recommended_difficulty"

    X = df[feature_cols]
    y = df[target_col]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestClassifier(n_estimators=100, max_depth=8, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Model Training Complete! Test Accuracy: {acc * 100:.2f}%")
    print(classification_report(y_test, y_pred))

    os.makedirs(MODEL_OUTPUT_DIR, exist_ok=True)
    model_path = os.path.join(MODEL_OUTPUT_DIR, "dda_model.joblib")
    joblib.dump({"model": model, "feature_names": feature_cols}, model_path)
    print(f"Saved DDA model artifact to {model_path}")


if __name__ == "__main__":
    train_dda_model()
