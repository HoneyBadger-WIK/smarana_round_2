"""
SMARANA Dataset Cleaning & Feature Preprocessing Pipeline
Processes raw research datasets into normalized feature matrices for DDA model training.
"""

import os
import pandas as pd
import numpy as np

RAW_DATASET_DIR = "/home/harshithkashyap/Desktop/sih 2026/dataset"
OUTPUT_DATA_DIR = "/home/harshithkashyap/Desktop/sih 2026/smarana/ml/data"


def clean_health_data():
    """Clean and transform dementia_patients_health_data.csv into DDA features."""
    raw_path = os.path.join(RAW_DATASET_DIR, "dementia_patients_health_data.csv")
    if not os.path.exists(raw_path):
        print(f"Raw dataset not found at {raw_path}")
        return None

    print(f"Processing {raw_path}...")
    df = pd.read_csv(raw_path)

    # Clean missing values
    df["Cognitive_Test_Scores"] = pd.to_numeric(df["Cognitive_Test_Scores"], errors="coerce").fillna(5.0)
    df["Age"] = pd.to_numeric(df["Age"], errors="coerce").fillna(65.0)

    # Encode categorical features
    physical_act_map = {"Sedentary": 0, "Mild Activity": 1, "Moderate Activity": 2, "Vigorous Activity": 3}
    sleep_map = {"Poor": 0, "Fair": 1, "Good": 2, "Excellent": 3}
    
    df["Physical_Activity_Encoded"] = df["Physical_Activity"].map(physical_act_map).fillna(1)
    df["Sleep_Quality_Encoded"] = df["Sleep_Quality"].map(sleep_map).fillna(1)
    df["Depression_Encoded"] = df["Depression_Status"].apply(lambda x: 1 if str(x).strip().lower() == "yes" else 0)

    # Create target recommended difficulty (1-5 scale) based on cognitive performance
    # Cognitive_Test_Scores ranges 0-10 in this dataset
    df["CPI_Score"] = (df["Cognitive_Test_Scores"] / 10.0) * 100.0
    df["Target_Difficulty"] = np.select(
        [
            df["CPI_Score"] < 30,
            (df["CPI_Score"] >= 30) & (df["CPI_Score"] < 50),
            (df["CPI_Score"] >= 50) & (df["CPI_Score"] < 70),
            (df["CPI_Score"] >= 70) & (df["CPI_Score"] < 85),
            df["CPI_Score"] >= 85,
        ],
        [1, 2, 3, 4, 5],
        default=3
    )

    out_path = os.path.join(OUTPUT_DATA_DIR, "cleaned_cognitive_data.csv")
    os.makedirs(OUTPUT_DATA_DIR, exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f"Saved cleaned health data to {out_path} ({len(df)} records).")
    return df


def clean_eeg_data():
    """Clean and transform EEG_MCSAD_Dataset.csv."""
    raw_path = os.path.join(RAW_DATASET_DIR, "EEG_MCSAD_Dataset.csv")
    if not os.path.exists(raw_path):
        print(f"Raw EEG dataset not found at {raw_path}")
        return None

    print(f"Processing {raw_path}...")
    df = pd.read_csv(raw_path)

    # Normalize Cognitive_TaskScore to 0-100 scale
    task_max = df["Cognitive_TaskScore"].max()
    df["Normalized_Cognitive_Score"] = (df["Cognitive_TaskScore"] / (task_max if task_max > 0 else 100)) * 100.0

    out_path = os.path.join(OUTPUT_DATA_DIR, "cleaned_eeg_data.csv")
    os.makedirs(OUTPUT_DATA_DIR, exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f"Saved cleaned EEG data to {out_path} ({len(df)} records).")
    return df


if __name__ == "__main__":
    clean_health_data()
    clean_eeg_data()
