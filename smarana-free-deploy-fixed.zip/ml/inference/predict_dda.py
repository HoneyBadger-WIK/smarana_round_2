"""
SMARANA ML — Adaptive Difficulty Adjustment (DDA) Inference Engine
Loads trained Random Forest model artifact for predictive difficulty estimation,
with automatic fallback to rule-based DDA engine.
"""

import os
import logging
from typing import Dict, Any, Optional
import joblib

from app.services.dda_engine import evaluate_session, DDAResult

logger = logging.getLogger("smarana.ml.inference")

MODEL_PATH = "/home/harshithkashyap/Desktop/sih 2026/smarana/ml/models/dda_model.joblib"


class DDAInferenceEngine:
    """Predictive DDA Inference with rule-based fallback."""
    def __init__(self, model_path: str = MODEL_PATH):
        self.model_path = model_path
        self.model = None
        self.feature_names = []
        self._load_model()

    def _load_model(self):
        if os.path.exists(self.model_path):
            try:
                artifact = joblib.load(self.model_path)
                self.model = artifact.get("model")
                self.feature_names = artifact.get("feature_names", [])
                logger.info(f"Successfully loaded ML DDA model from {self.model_path}")
            except Exception as e:
                logger.warning(f"Failed to load DDA model ({e}). Will use rule-based engine.")

    def predict(
        self,
        accuracy: float,
        reaction_time_ms: float,
        memory_score: float,
        attention_span_sec: float,
        recall_score: float,
        error_count: int,
        attempts: int,
        current_difficulty: int,
        min_difficulty: int = 1,
        max_difficulty: int = 5,
    ) -> DDAResult:
        """Predict optimal difficulty using ML model if available, else evaluate via rule engine."""
        # Always run deterministic rule engine for baseline CPI score and explainability
        rule_result = evaluate_session(
            accuracy=accuracy,
            reaction_time_ms=reaction_time_ms,
            memory_score=memory_score,
            attention_span_sec=attention_span_sec,
            recall_score=recall_score,
            error_count=error_count,
            attempts=attempts,
            current_difficulty=current_difficulty,
            min_difficulty=min_difficulty,
            max_difficulty=max_difficulty,
        )

        if self.model is None:
            return rule_result

        try:
            features = [[
                accuracy,
                reaction_time_ms,
                memory_score,
                attention_span_sec,
                recall_score,
                error_count,
                attempts,
                current_difficulty,
            ]]
            ml_pred_difficulty = int(self.model.predict(features)[0])
            # Clamp to min/max
            ml_pred_difficulty = max(min_difficulty, min(max_difficulty, ml_pred_difficulty))

            direction = "maintain"
            if ml_pred_difficulty > current_difficulty:
                direction = "increase"
            elif ml_pred_difficulty < current_difficulty:
                direction = "decrease"

            reason = (
                f"{rule_result.reason} [ML-Guided DDA: Level {ml_pred_difficulty}]"
            )

            return DDAResult(
                cpi_score=rule_result.cpi_score,
                recommended_difficulty=ml_pred_difficulty,
                direction=direction,
                reason=reason,
                rule_triggered=f"ML_RandomForest_v1 + {rule_result.rule_triggered}",
            )
        except Exception as e:
            logger.error(f"ML inference error: {e}. Falling back to rule engine.")
            return rule_result


# Global inference instance
dda_inference_engine = DDAInferenceEngine()
