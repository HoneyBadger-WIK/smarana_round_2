"""
SMARANA Integrations & External Service Abstractions with Graceful Fallbacks.
(Section 9 of Spec)

Covers:
- LLM API for Companion Conversation (Fallback: Scripted empathetic response tree)
- STT / TTS Voice Service (Fallback: Text + browser/system default TTS)
- SMS / Telephony Alert Dispatcher (Fallback: Mock log output)
"""

import logging
import random
from typing import Dict, Any, Optional

from app.config import settings

logger = logging.getLogger("smarana.integrations")


# ─── LLM Companion Abstraction ────────────────────────────────────────────────

class LLMCompanionService:
    """LLM integration for warm companion dialogue with fallback scripted response tree."""
    
    SCRIPTED_RESPONSES = {
        "greeting": [
            "Good morning! It is so wonderful to see you today. Have you had your morning tea yet?",
            "Hello my friend! I was just thinking about you. Shall we start our daily journey together?",
            "Namaste! Hope you are feeling bright and refreshed today.",
        ],
        "comfort": [
            "I hear you, and it's completely okay to feel that way. Taking things one step at a time is always wise.",
            "Thank you for sharing that with me. Remember, your family and I are always here cheering for you.",
            "That sounds like a lot on your mind. Would you like to play a gentle memory activity or listen to some music?",
        ],
        "reminiscence": [
            "What a beautiful memory! Photos and stories from family bring back such warmth.",
            "I love hearing about your experiences. That sounds like a wonderful celebration.",
        ],
        "default": [
            "Thank you for telling me that. Let's make today a happy day together!",
            "I'm here with you. What activity would you like to explore next?",
        ]
    }

    async def generate_response(self, user_message: str, companion_name: str = "Anaya", language: str = "en") -> str:
        """Generate response via LLM if available; otherwise use scripted fallback."""
        if settings.LLM_API_KEY and settings.LLM_API_URL:
            try:
                # Place real HTTP call to LLM API here if configured
                logger.info(f"Calling external LLM for {companion_name}")
                # ...
            except Exception as e:
                logger.warning(f"LLM API call failed ({e}). Falling back to scripted responses.")

        # Fallback scripted response logic
        msg_lower = user_message.lower()
        if any(word in msg_lower for word in ["hello", "hi", "morning", "namaste"]):
            category = "greeting"
        elif any(word in msg_lower for word in ["sad", "tired", "worry", "lonely", "confused"]):
            category = "comfort"
        elif any(word in msg_lower for word in ["photo", "remember", "past", "family", "festival"]):
            category = "reminiscence"
        else:
            category = "default"

        return random.choice(self.SCRIPTED_RESPONSES[category])


# ─── Speech Services Abstraction ──────────────────────────────────────────────

class SpeechService:
    """STT/TTS integration abstraction with fallback."""
    
    async def text_to_speech(self, text: str, language_code: str = "en") -> Dict[str, Any]:
        """Convert text to speech audio URL or metadata."""
        if settings.TTS_API_KEY:
            # External TTS call
            pass
        return {
            "use_system_tts": True,
            "text": text,
            "language_code": language_code,
            "fallback_message": "System default TTS voice used.",
        }

    async def speech_to_text(self, audio_bytes: bytes, language_code: str = "en") -> Dict[str, Any]:
        """Convert speech audio to text."""
        if settings.STT_API_KEY:
            # External STT call
            pass
        return {
            "text": "Fallback speech recognition text",
            "confidence": 0.95,
            "is_fallback": True,
        }


# ─── Telephony / SMS Service ─────────────────────────────────────────────────

class TelephonyService:
    """SMS / SOS alert dispatcher with mock demo sandbox."""
    
    async def send_sms_alert(self, phone: str, message: str, is_sos: bool = False) -> Dict[str, Any]:
        """Dispatch SMS or log to sandbox."""
        if settings.SMS_API_KEY:
            logger.info(f"Dispatching SMS to {phone}: {message}")
            return {"status": "dispatched", "provider": "twilio_or_fast2sms", "to": phone}
        else:
            logger.info(f"[MOCK SMS SANDBOX] Would send to {phone}: '{message}' (SOS={is_sos})")
            return {
                "status": "mock_dispatched",
                "message": "Mock mode active. SMS logged safely for demo.",
                "to": phone,
                "content": message,
            }


# Singleton service instances
llm_service = LLMCompanionService()
speech_service = SpeechService()
telephony_service = TelephonyService()
