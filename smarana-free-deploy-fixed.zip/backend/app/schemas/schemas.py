"""
SMARANA Pydantic Schemas — Request/response models for all API endpoints.
"""

import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr, Field


# ─── Auth ───────────────────────────────────────────────────────────────────


class SignupRequest(BaseModel):
    email: Optional[str] = None
    phone: Optional[str] = None
    password: str = Field(..., min_length=8)
    role: str = "elder_user"
    name: str = Field(..., min_length=1)


class LoginRequest(BaseModel):
    username: str  # email or phone
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    role: str
    user_id: int


class RefreshRequest(BaseModel):
    refresh_token: str


# ─── Users / Profiles ──────────────────────────────────────────────────────


class ElderProfileCreate(BaseModel):
    name: str
    age: int = Field(..., ge=1, le=150)
    gender: Optional[str] = None
    education_level: Optional[str] = None
    primary_language: str = "en"
    location: Optional[str] = None
    companion_name: Optional[str] = None
    companion_type: Optional[str] = None
    interests: list[str] = []
    font_size: str = "large"
    high_contrast: bool = False
    voice_first_mode: bool = False


class ElderProfileResponse(BaseModel):
    id: int
    user_id: int
    name: str
    age: int
    gender: Optional[str]
    education_level: Optional[str]
    primary_language: str
    location: Optional[str]
    companion_name: Optional[str]
    companion_type: Optional[str]
    interests: Optional[list[str]]
    font_size: str
    high_contrast: bool
    voice_first_mode: bool

    model_config = {"from_attributes": True}


class UserResponse(BaseModel):
    id: int
    email: Optional[str]
    phone: Optional[str]
    role: str
    is_active: bool
    created_at: datetime.datetime
    elder_profile: Optional[ElderProfileResponse] = None

    model_config = {"from_attributes": True}


class FamilyMemberCreate(BaseModel):
    elder_id: int
    name: str
    relationship: str
    permission_scope: list[str] = ["view_engagement"]


class FamilyMemberResponse(BaseModel):
    id: int
    user_id: int
    elder_id: int
    name: str
    relationship: str
    permission_scope: list[str]
    created_at: datetime.datetime

    model_config = {"from_attributes": True}


# ─── Game Sessions ─────────────────────────────────────────────────────────


class GameSessionCreate(BaseModel):
    patient_id: int
    game_type_id: int
    difficulty_level: int = Field(1, ge=1, le=5)
    game_duration_sec: float = 0
    attempts: int = 0
    hints_used: int = 0
    reaction_time_ms: float = 0
    error_count: int = 0
    accuracy_percentage: float = Field(0, ge=0, le=100)
    memory_score: float = Field(0, ge=0, le=100)
    attention_span_sec: float = 0
    recall_score: float = Field(0, ge=0, le=100)
    pattern_recognition_score: float = Field(0, ge=0, le=100)
    object_recognition_score: float = Field(0, ge=0, le=100)


class GameSessionResponse(BaseModel):
    session_id: int
    patient_id: int
    game_type_id: int
    date: datetime.datetime
    difficulty_level: int
    game_duration_sec: float
    attempts: int
    hints_used: int
    reaction_time_ms: float
    error_count: int
    accuracy_percentage: float
    memory_score: float
    attention_span_sec: float
    recall_score: float
    pattern_recognition_score: float
    object_recognition_score: float
    cpi_score: Optional[float]
    recommended_difficulty: Optional[int]
    recommendation_reason: Optional[str]

    model_config = {"from_attributes": True}


class GameTypeResponse(BaseModel):
    id: int
    name: str
    display_name: str
    description: Optional[str]
    cognitive_domains: list[str]
    min_difficulty: int
    max_difficulty: int

    model_config = {"from_attributes": True}


# ─── DDA Engine ─────────────────────────────────────────────────────────────


class DDARecommendation(BaseModel):
    cpi_score: float = Field(..., description="Composite Performance Index (0-100)")
    current_difficulty: int
    recommended_difficulty: int
    direction: str  # "increase", "decrease", "maintain"
    reason: str  # Explainability string
    domain_scores: dict[str, float]


# ─── Cognitive Metrics ──────────────────────────────────────────────────────


class CognitiveMetricResponse(BaseModel):
    domain: str
    current_score: float
    previous_score: float
    trend_direction: str
    percent_change: float
    rolling_avg_recent: float
    rolling_avg_baseline: float
    last_calculated_at: datetime.datetime

    model_config = {"from_attributes": True}


class CognitiveTrendPoint(BaseModel):
    date: datetime.datetime
    score: float


class CognitiveTrendResponse(BaseModel):
    domain: str
    trend_direction: str
    data_points: list[CognitiveTrendPoint]


# ─── Reminders ──────────────────────────────────────────────────────────────


class ReminderCreate(BaseModel):
    patient_id: int
    type: str
    title: str
    description: Optional[str] = None
    schedule_time: Optional[str] = None
    schedule_days: list[str] = []
    dosage: Optional[str] = None
    instructions: Optional[str] = None


class ReminderResponse(BaseModel):
    id: int
    patient_id: int
    type: str
    title: str
    description: Optional[str]
    schedule_time: Optional[str]
    schedule_days: Optional[list[str]]
    dosage: Optional[str]
    instructions: Optional[str]
    status: str
    is_active: bool
    last_completed_at: Optional[datetime.datetime]
    created_at: datetime.datetime

    model_config = {"from_attributes": True}


class ReminderUpdate(BaseModel):
    status: Optional[str] = None
    is_active: Optional[bool] = None


# ─── Mood ───────────────────────────────────────────────────────────────────


class MoodCheckinCreate(BaseModel):
    patient_id: int
    mood_value: int = Field(..., ge=1, le=5)
    notes: Optional[str] = None


class MoodCheckinResponse(BaseModel):
    id: int
    patient_id: int
    date: datetime.date
    mood_value: int
    notes: Optional[str]

    model_config = {"from_attributes": True}


# ─── Alerts ─────────────────────────────────────────────────────────────────


class AlertResponse(BaseModel):
    id: int
    patient_id: int
    type: str
    message: str
    severity: str
    is_acknowledged: bool
    acknowledged_by: Optional[int]
    created_at: datetime.datetime

    model_config = {"from_attributes": True}


# ─── Dashboard ──────────────────────────────────────────────────────────────


class PatientSummary(BaseModel):
    patient_id: int
    name: str
    age: int
    primary_language: str
    current_streak: int
    total_sessions: int
    last_session_date: Optional[datetime.datetime]
    cognitive_domains: list[CognitiveMetricResponse]
    pending_alerts: int
    reminder_adherence_percent: float
    last_mood: Optional[int]


class DashboardOverview(BaseModel):
    patients: list[PatientSummary]
    total_alerts: int
    total_sessions_today: int


# ─── Sync ───────────────────────────────────────────────────────────────────


class SyncPushRequest(BaseModel):
    items: list[dict]


class SyncPullResponse(BaseModel):
    last_sync_timestamp: datetime.datetime
    items: list[dict]
