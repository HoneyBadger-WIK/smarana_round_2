"""
SMARANA Cognitive Metrics API Router
Provides cognitive domain metrics and trend data for the dashboard.
"""

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.models import CognitiveMetric, GameSession, User
from app.schemas.schemas import CognitiveMetricResponse, CognitiveTrendResponse, CognitiveTrendPoint
from app.auth.auth import get_current_user
from app.services.cognitive_trends import DOMAIN_COLUMN_MAP

router = APIRouter(prefix="/api/cognitive", tags=["Cognitive Metrics"])


@router.get("/metrics/{patient_id}", response_model=list[CognitiveMetricResponse])
def get_cognitive_metrics(
    patient_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get current cognitive domain metrics for a patient."""
    metrics = (
        db.query(CognitiveMetric)
        .filter(CognitiveMetric.patient_id == patient_id)
        .all()
    )
    return metrics


@router.get("/trends/{patient_id}", response_model=list[CognitiveTrendResponse])
def get_cognitive_trends(
    patient_id: int,
    domain: str = Query(None, description="Filter by specific domain"),
    window: int = Query(30, description="Number of sessions to include"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get historical trend data for cognitive domains."""
    domains_to_query = [domain] if domain else list(DOMAIN_COLUMN_MAP.keys())
    results = []

    for d in domains_to_query:
        col = DOMAIN_COLUMN_MAP.get(d)
        if not col:
            continue

        sessions = (
            db.query(GameSession)
            .filter(GameSession.patient_id == patient_id)
            .order_by(GameSession.date.asc())
            .limit(window)
            .all()
        )

        data_points = [
            CognitiveTrendPoint(
                date=s.date,
                score=getattr(s, col, 0) or 0,
            )
            for s in sessions
        ]

        # Get current trend direction from metrics
        metric = (
            db.query(CognitiveMetric)
            .filter(
                CognitiveMetric.patient_id == patient_id,
                CognitiveMetric.domain == d,
            )
            .first()
        )

        results.append(
            CognitiveTrendResponse(
                domain=d,
                trend_direction=metric.trend_direction if metric else "stable",
                data_points=data_points,
            )
        )

    return results
