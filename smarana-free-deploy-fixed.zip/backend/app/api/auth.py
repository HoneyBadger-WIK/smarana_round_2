"""
SMARANA Auth API Router
Handles signup, login, token refresh, and role management.
"""

import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.models import User, ElderProfile, FamilyMember, HealthcareProfessional, UserRole
from app.schemas.schemas import (
    SignupRequest, TokenResponse, RefreshRequest,
    ElderProfileCreate, FamilyMemberCreate, FamilyMemberResponse,
)
from app.auth.auth import (
    hash_password, verify_password,
    create_access_token, create_refresh_token, decode_token,
    get_current_user,
)

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


@router.post("/signup", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
def signup(req: SignupRequest, db: Session = Depends(get_db)):
    """Register a new user with role-specific profile creation."""
    # Check duplicates
    if req.email:
        existing = db.query(User).filter(User.email == req.email).first()
        if existing:
            raise HTTPException(status_code=400, detail="Email already registered")
    if req.phone:
        existing = db.query(User).filter(User.phone == req.phone).first()
        if existing:
            raise HTTPException(status_code=400, detail="Phone already registered")

    user = User(
        email=req.email,
        phone=req.phone,
        password_hash=hash_password(req.password),
        role=req.role,
    )
    db.add(user)
    db.flush()  # Get user.id

    # Create role-specific profile
    if req.role == UserRole.ELDER_USER.value:
        profile = ElderProfile(
            user_id=user.id,
            name=req.name,
            age=65,  # Default, updated via profile endpoint
        )
        db.add(profile)
    elif req.role == UserRole.HEALTHCARE_PROFESSIONAL.value:
        hp = HealthcareProfessional(
            user_id=user.id,
            name=req.name,
        )
        db.add(hp)

    db.commit()
    db.refresh(user)

    access_token = create_access_token({"sub": str(user.id), "role": user.role})
    refresh_token = create_refresh_token({"sub": str(user.id)})

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        role=user.role,
        user_id=user.id,
    )


@router.post("/login", response_model=TokenResponse)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """Login with email/phone + password. Returns JWT tokens."""
    user = (
        db.query(User)
        .filter((User.email == form_data.username) | (User.phone == form_data.username))
        .first()
    )
    if not user or not verify_password(form_data.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

    access_token = create_access_token({"sub": str(user.id), "role": user.role})
    refresh_token = create_refresh_token({"sub": str(user.id)})

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        role=user.role,
        user_id=user.id,
    )


@router.post("/refresh", response_model=TokenResponse)
def refresh_token(req: RefreshRequest, db: Session = Depends(get_db)):
    """Refresh an expired access token using a valid refresh token."""
    payload = decode_token(req.refresh_token)
    if payload.get("type") != "refresh":
        raise HTTPException(status_code=400, detail="Invalid refresh token")

    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    access_token = create_access_token({"sub": user.id, "role": user.role})
    new_refresh = create_refresh_token({"sub": user.id})

    return TokenResponse(
        access_token=access_token,
        refresh_token=new_refresh,
        role=user.role,
        user_id=user.id,
    )


@router.get("/me")
def get_me(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Get current user info including role-specific profile."""
    result = {
        "id": current_user.id,
        "email": current_user.email,
        "phone": current_user.phone,
        "role": current_user.role,
        "is_active": current_user.is_active,
    }

    if current_user.role == UserRole.ELDER_USER.value:
        profile = (
            db.query(ElderProfile).filter(ElderProfile.user_id == current_user.id).first()
        )
        if profile:
            result["elder_profile"] = {
                "id": profile.id,
                "name": profile.name,
                "age": profile.age,
                "primary_language": profile.primary_language,
                "companion_name": profile.companion_name,
            }

    return result
