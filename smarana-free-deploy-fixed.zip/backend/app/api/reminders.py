"""
SMARANA Reminders API Router
CRUD for reminders, adherence tracking, and mood check-ins.
"""

import datetime
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database import get_db
from app.models.models import Reminder, MoodCheckin, User, ReminderStatus
from app.schemas.schemas import (
    ReminderCreate, ReminderResponse, ReminderUpdate,
    MoodCheckinCreate, MoodCheckinResponse,
)
from app.auth.auth import get_current_user

router = APIRouter(prefix="/api/reminders", tags=["Reminders & Routines"])


# ─── Reminders ──────────────────────────────────────────────────────────────


@router.get("/{patient_id}", response_model=list[ReminderResponse])
def get_reminders(
    patient_id: int,
    active_only: bool = Query(True),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get all reminders for a patient."""
    query = db.query(Reminder).filter(Reminder.patient_id == patient_id)
    if active_only:
        query = query.filter(Reminder.is_active == True)
    return query.order_by(Reminder.schedule_time).all()


@router.post("/", response_model=ReminderResponse, status_code=201)
def create_reminder(
    reminder: ReminderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Create a new reminder (medicine, hydration, activity, or appointment)."""
    db_reminder = Reminder(**reminder.model_dump())
    db.add(db_reminder)
    db.commit()
    db.refresh(db_reminder)
    return db_reminder


@router.patch("/{reminder_id}", response_model=ReminderResponse)
def update_reminder(
    reminder_id: int,
    update: ReminderUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Update reminder status (complete, snooze, deactivate)."""
    reminder = db.query(Reminder).filter(Reminder.id == reminder_id).first()
    if not reminder:
        raise HTTPException(status_code=404, detail="Reminder not found")

    if update.status is not None:
        reminder.status = update.status
        if update.status == ReminderStatus.COMPLETED.value:
            reminder.last_completed_at = datetime.datetime.utcnow()
    if update.is_active is not None:
        reminder.is_active = update.is_active

    db.commit()
    db.refresh(reminder)
    return reminder


@router.get("/adherence/{patient_id}")
def get_adherence(
    patient_id: int,
    days: int = Query(7, le=90),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get reminder adherence stats for a patient."""
    total = db.query(Reminder).filter(
        Reminder.patient_id == patient_id,
        Reminder.is_active == True,
    ).count()

    completed = db.query(Reminder).filter(
        Reminder.patient_id == patient_id,
        Reminder.status == ReminderStatus.COMPLETED.value,
    ).count()

    missed = db.query(Reminder).filter(
        Reminder.patient_id == patient_id,
        Reminder.status == ReminderStatus.MISSED.value,
    ).count()

    adherence_pct = (completed / total * 100) if total > 0 else 0

    return {
        "total_reminders": total,
        "completed": completed,
        "missed": missed,
        "pending": total - completed - missed,
        "adherence_percent": round(adherence_pct, 1),
    }


# ─── Mood Check-ins ────────────────────────────────────────────────────────


@router.post("/mood", response_model=MoodCheckinResponse, status_code=201)
def create_mood_checkin(
    checkin: MoodCheckinCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Record a mood check-in."""
    mood = MoodCheckin(
        patient_id=checkin.patient_id,
        date=datetime.date.today(),
        mood_value=checkin.mood_value,
        notes=checkin.notes,
    )
    db.add(mood)
    db.commit()
    db.refresh(mood)
    return mood


@router.get("/mood/{patient_id}", response_model=list[MoodCheckinResponse])
def get_mood_history(
    patient_id: int,
    limit: int = Query(30, le=90),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get mood check-in history."""
    return (
        db.query(MoodCheckin)
        .filter(MoodCheckin.patient_id == patient_id)
        .order_by(MoodCheckin.date.desc())
        .limit(limit)
        .all()
    )
