"""
SMARANA Games API Router
Handles game types, session recording, session history, and DDA recommendations.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.models import GameType, GameSession, UserRole
from app.schemas.schemas import (
    GameSessionCreate, GameSessionResponse, GameTypeResponse,
    DDARecommendation,
)
from app.auth.auth import get_current_user, require_role
from app.models.models import User
from app.services.dda_engine import evaluate_session
from app.services.cognitive_trends import update_cognitive_metrics

router = APIRouter(prefix="/api/games", tags=["Games & Sessions"])


@router.get("/types", response_model=list[GameTypeResponse])
def list_game_types(db: Session = Depends(get_db)):
    """List all available game types."""
    return db.query(GameType).filter(GameType.is_active == True).all()


@router.post("/sessions", response_model=GameSessionResponse, status_code=201)
def record_session(
    session_data: GameSessionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Record a completed game session and get DDA recommendation.
    Automatically computes CPI, stores recommendation, and updates cognitive metrics.
    """
    # Validate game type exists
    game_type = db.query(GameType).filter(GameType.id == session_data.game_type_id).first()
    if not game_type:
        raise HTTPException(status_code=404, detail="Game type not found")

    # Run DDA engine
    dda_result = evaluate_session(
        accuracy=session_data.accuracy_percentage,
        reaction_time_ms=session_data.reaction_time_ms,
        memory_score=session_data.memory_score,
        attention_span_sec=session_data.attention_span_sec,
        recall_score=session_data.recall_score,
        error_count=session_data.error_count,
        attempts=session_data.attempts,
        current_difficulty=session_data.difficulty_level,
        min_difficulty=game_type.min_difficulty,
        max_difficulty=game_type.max_difficulty,
    )

    # Create session record with DDA output
    game_session = GameSession(
        patient_id=session_data.patient_id,
        game_type_id=session_data.game_type_id,
        difficulty_level=session_data.difficulty_level,
        game_duration_sec=session_data.game_duration_sec,
        attempts=session_data.attempts,
        hints_used=session_data.hints_used,
        reaction_time_ms=session_data.reaction_time_ms,
        error_count=session_data.error_count,
        accuracy_percentage=session_data.accuracy_percentage,
        memory_score=session_data.memory_score,
        attention_span_sec=session_data.attention_span_sec,
        recall_score=session_data.recall_score,
        pattern_recognition_score=session_data.pattern_recognition_score,
        object_recognition_score=session_data.object_recognition_score,
        cpi_score=dda_result.cpi_score,
        recommended_difficulty=dda_result.recommended_difficulty,
        recommendation_reason=dda_result.reason,
    )
    db.add(game_session)
    db.commit()
    db.refresh(game_session)

    # Update cognitive metrics in background
    update_cognitive_metrics(db, session_data.patient_id)

    return game_session


@router.get("/sessions/{patient_id}", response_model=list[GameSessionResponse])
def get_sessions(
    patient_id: int,
    limit: int = Query(20, le=100),
    offset: int = 0,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get game session history for a patient."""
    sessions = (
        db.query(GameSession)
        .filter(GameSession.patient_id == patient_id)
        .order_by(GameSession.date.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )
    return sessions


@router.get("/dda/{patient_id}", response_model=DDARecommendation)
def get_dda_recommendation(
    patient_id: int,
    game_type_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get DDA recommendation based on the last session for a specific game type."""
    last_session = (
        db.query(GameSession)
        .filter(
            GameSession.patient_id == patient_id,
            GameSession.game_type_id == game_type_id,
        )
        .order_by(GameSession.date.desc())
        .first()
    )

    if not last_session:
        # No history — start at minimum difficulty
        return DDARecommendation(
            cpi_score=50.0,
            current_difficulty=1,
            recommended_difficulty=1,
            direction="maintain",
            reason="Welcome! Starting at Level 1. Enjoy the activity at your own pace.",
            domain_scores={"memory": 0, "attention": 0, "recall": 0, "accuracy": 0, "reaction_speed": 0},
        )

    return DDARecommendation(
        cpi_score=last_session.cpi_score or 50.0,
        current_difficulty=last_session.difficulty_level,
        recommended_difficulty=last_session.recommended_difficulty or last_session.difficulty_level,
        direction="maintain",
        reason=last_session.recommendation_reason or "Continue at your current level.",
        domain_scores={
            "memory": last_session.memory_score,
            "attention": last_session.attention_span_sec,
            "recall": last_session.recall_score,
            "accuracy": last_session.accuracy_percentage,
            "reaction_speed": last_session.reaction_time_ms,
        },
    )
