"""
SMARANA Dashboard API Router
Aggregated views for caregivers and healthcare professionals.
"""

import datetime
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database import get_db
from app.models.models import (
    User, ElderProfile, GameSession, CognitiveMetric,
    Reminder, MoodCheckin, Streak, Alert, FamilyMember,
    PatientPanel, UserRole, ReminderStatus,
)
from app.schemas.schemas import (
    PatientSummary, DashboardOverview, CognitiveMetricResponse, AlertResponse,
)
from app.auth.auth import get_current_user, require_role

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])


def _build_patient_summary(db: Session, elder: ElderProfile) -> PatientSummary:
    """Build a summary for a single patient."""
    # Total sessions
    total_sessions = db.query(GameSession).filter(
        GameSession.patient_id == elder.id
    ).count()

    # Last session
    last_session = (
        db.query(GameSession)
        .filter(GameSession.patient_id == elder.id)
        .order_by(GameSession.date.desc())
        .first()
    )

    # Cognitive metrics
    metrics = (
        db.query(CognitiveMetric)
        .filter(CognitiveMetric.patient_id == elder.id)
        .all()
    )

    # Streak
    streak = db.query(Streak).filter(Streak.patient_id == elder.id).first()

    # Pending alerts
    pending_alerts = db.query(Alert).filter(
        Alert.patient_id == elder.id,
        Alert.is_acknowledged == False,
    ).count()

    # Reminder adherence
    total_reminders = db.query(Reminder).filter(
        Reminder.patient_id == elder.id,
        Reminder.is_active == True,
    ).count()
    completed_reminders = db.query(Reminder).filter(
        Reminder.patient_id == elder.id,
        Reminder.status == ReminderStatus.COMPLETED.value,
    ).count()
    adherence = (completed_reminders / total_reminders * 100) if total_reminders > 0 else 0

    # Last mood
    last_mood_record = (
        db.query(MoodCheckin)
        .filter(MoodCheckin.patient_id == elder.id)
        .order_by(MoodCheckin.date.desc())
        .first()
    )

    return PatientSummary(
        patient_id=elder.id,
        name=elder.name,
        age=elder.age,
        primary_language=elder.primary_language,
        current_streak=streak.current_streak if streak else 0,
        total_sessions=total_sessions,
        last_session_date=last_session.date if last_session else None,
        cognitive_domains=[
            CognitiveMetricResponse.model_validate(m) for m in metrics
        ],
        pending_alerts=pending_alerts,
        reminder_adherence_percent=round(adherence, 1),
        last_mood=last_mood_record.mood_value if last_mood_record else None,
    )


@router.get("/overview", response_model=DashboardOverview)
def get_dashboard_overview(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Get dashboard overview. Content depends on the user's role:
    - FAMILY_MEMBER: sees their linked elders only
    - HEALTHCARE_PROFESSIONAL: sees their patient panel
    - ADMIN: sees all patients
    """
    if current_user.role == UserRole.FAMILY_MEMBER.value:
        links = db.query(FamilyMember).filter(
            FamilyMember.user_id == current_user.id
        ).all()
        elder_ids = [l.elder_id for l in links]
        elders = db.query(ElderProfile).filter(ElderProfile.id.in_(elder_ids)).all()

    elif current_user.role == UserRole.HEALTHCARE_PROFESSIONAL.value:
        hp = db.query(User).filter(User.id == current_user.id).first()
        from app.models.models import HealthcareProfessional
        hp_profile = db.query(HealthcareProfessional).filter(
            HealthcareProfessional.user_id == current_user.id
        ).first()
        if hp_profile:
            panels = db.query(PatientPanel).filter(
                PatientPanel.healthcare_id == hp_profile.id
            ).all()
            elder_ids = [p.patient_id for p in panels]
            elders = db.query(ElderProfile).filter(ElderProfile.id.in_(elder_ids)).all()
        else:
            elders = []
    else:
        # Admin or elder can see all (simplified for demo)
        elders = db.query(ElderProfile).all()

    patients = [_build_patient_summary(db, e) for e in elders]

    # Today's sessions count
    today = datetime.date.today()
    sessions_today = db.query(GameSession).filter(
        func.date(GameSession.date) == today
    ).count()

    total_alerts = sum(p.pending_alerts for p in patients)

    return DashboardOverview(
        patients=patients,
        total_alerts=total_alerts,
        total_sessions_today=sessions_today,
    )


@router.get("/alerts/{patient_id}", response_model=list[AlertResponse])
def get_patient_alerts(
    patient_id: int,
    unacknowledged_only: bool = Query(True),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get alerts for a specific patient."""
    query = db.query(Alert).filter(Alert.patient_id == patient_id)
    if unacknowledged_only:
        query = query.filter(Alert.is_acknowledged == False)
    return query.order_by(Alert.created_at.desc()).all()


@router.patch("/alerts/{alert_id}/acknowledge")
def acknowledge_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Acknowledge an alert."""
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.is_acknowledged = True
    alert.acknowledged_by = current_user.id
    db.commit()
    return {"status": "acknowledged"}
