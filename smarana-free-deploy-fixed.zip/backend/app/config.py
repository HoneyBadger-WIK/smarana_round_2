"""
SMARANA Backend Configuration
Loads settings from environment variables via pydantic-settings.
"""

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Database
    DATABASE_URL: str = "sqlite:///./smarana_dev.db"

    # Redis
    REDIS_URL: Optional[str] = None

    # Auth
    JWT_SECRET: str = "dev-secret-change-me-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # External services (all optional with mock fallbacks)
    LLM_API_KEY: Optional[str] = None
    LLM_API_URL: Optional[str] = None
    STT_API_KEY: Optional[str] = None
    TTS_API_KEY: Optional[str] = None
    SMS_API_KEY: Optional[str] = None
    FCM_SERVER_KEY: Optional[str] = None

    # Object storage
    OBJECT_STORAGE_ENDPOINT: Optional[str] = None
    OBJECT_STORAGE_BUCKET: Optional[str] = None
    OBJECT_STORAGE_ACCESS_KEY: Optional[str] = None
    OBJECT_STORAGE_SECRET_KEY: Optional[str] = None

    # ML
    MODEL_PATH: str = "./ml/models/dda_model.joblib"

    # App
    APP_ENV: str = "development"
    DEBUG: bool = True
    CORS_ORIGINS: str = "http://localhost:5173,http://localhost:3000"

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",")]

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()
