"""
SMARANA Backend — FastAPI Main Application Entrypoint
Problem Statement ID 26003 | SIH 2026

Coordinates authentication, game session recording, dynamic difficulty adjustment (DDA),
cognitive metric aggregation, offline sync, reminders, and live WebSocket streaming for dashboards.
"""

import logging
from pathlib import Path
from contextlib import asynccontextmanager
from typing import List, Dict, Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from app.config import settings
from app.database import engine, Base, get_db
from app.models.models import GameType, Language, User, ElderProfile, UserRole
from app.auth.auth import hash_password
from app.api.auth import router as auth_router
from app.api.games import router as games_router
from app.api.cognitive import router as cognitive_router
from app.api.dashboard import router as dashboard_router
from app.api.reminders import router as reminders_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("smarana")


# ─── WebSocket Connection Manager ─────────────────────────────────────────────

class ConnectionManager:
    """Manages real-time WebSocket connections for live caregiver/healthcare dashboards."""
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket connected. Total active: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
            logger.info(f"WebSocket disconnected. Remaining active: {len(self.active_connections)}")

    async def broadcast(self, message: Dict[str, Any]):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to WebSocket: {e}")

manager = ConnectionManager()


# ─── Database Seeding Function ────────────────────────────────────────────────

def seed_initial_data(db: Session):
    """Seed initial game types, languages, and demo accounts if they don't exist."""
    # Seed Game Types
    existing_games = db.query(GameType).count()
    if existing_games == 0:
        default_games = [
            GameType(
                name="memory_match",
                display_name="Memory Match",
                description="Pair cards featuring vibrant North-Eastern cultural motifs and textiles.",
                cognitive_domains=["memory", "working_memory", "visual_attention"],
                min_difficulty=1,
                max_difficulty=5,
            ),
            GameType(
                name="sequence_recall",
                display_name="Sequence Recall",
                description="Observe and reproduce sequences of traditional musical instruments and colors.",
                cognitive_domains=["working_memory", "attention", "sequence_recall"],
                min_difficulty=1,
                max_difficulty=5,
            ),
            GameType(
                name="attention_sweep",
                display_name="Attention Sweep",
                description="Find specific target elements among distracting regional crafts and flora.",
                cognitive_domains=["attention", "pattern_recognition"],
                min_difficulty=1,
                max_difficulty=5,
            ),
            GameType(
                name="regional_bazaar_sort",
                display_name="Regional Bazaar Sort",
                description="Categorize items from a bustling local bazaar into appropriate produce categories.",
                cognitive_domains=["semantic_categorization", "object_recognition"],
                min_difficulty=1,
                max_difficulty=5,
            ),
            GameType(
                name="memory_lane",
                display_name="Memory Lane (Reminiscence)",
                description="Recall special moments, photos, and stories shared by family members.",
                cognitive_domains=["episodic_memory", "recall"],
                min_difficulty=1,
                max_difficulty=5,
            ),
        ]
        db.add_all(default_games)
        logger.info("Seeded default GameTypes")

    # Seed Languages
    existing_langs = db.query(Language).count()
    if existing_langs == 0:
        languages = [
            Language(code="en", name="English", native_name="English", has_offline_stt=True, has_offline_tts=True),
            Language(code="hi", name="Hindi", native_name="हिन्दी", has_offline_stt=True, has_offline_tts=True),
            Language(code="as", name="Assamese", native_name="অসমীয়া", has_offline_stt=True, has_offline_tts=True),
            Language(code="bn", name="Bengali", native_name="বাংলা", has_offline_stt=True, has_offline_tts=True),
            Language(code="mni", name="Manipuri", native_name="মৈতৈলোন্", has_offline_stt=False, has_offline_tts=True),
            Language(code="brx", name="Bodo", native_name="बर'", has_offline_stt=False, has_offline_tts=True),
        ]
        db.add_all(languages)
        logger.info("Seeded default Languages")

    # Seed Demo Users if empty
    existing_users = db.query(User).count()
    if existing_users == 0:
        demo_elder = User(
            email="elder@smarana.in",
            phone="9876543210",
            password_hash=hash_password("password123"),
            role=UserRole.ELDER_USER.value,
        )
        db.add(demo_elder)
        db.flush()

        profile = ElderProfile(
            user_id=demo_elder.id,
            name="Grandpa Ramesh",
            age=72,
            primary_language="as",
            companion_name="Anaya",
            companion_type="Granddaughter",
            interests=["gardening", "folk music", "history"],
        )
        db.add(profile)

        demo_caregiver = User(
            email="caregiver@smarana.in",
            phone="9876543211",
            password_hash=hash_password("password123"),
            role=UserRole.FAMILY_MEMBER.value,
        )
        db.add(demo_caregiver)

        demo_hp = User(
            email="doctor@smarana.in",
            phone="9876543212",
            password_hash=hash_password("password123"),
            role=UserRole.HEALTHCARE_PROFESSIONAL.value,
        )
        db.add(demo_hp)

        db.commit()
        logger.info("Seeded demo user accounts")


# ─── Lifespan ─────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize DB tables
    logger.info("Initializing database tables...")
    Base.metadata.create_all(bind=engine)
    
    # Run seed
    with Session(engine) as db:
        seed_initial_data(db)

    yield
    logger.info("Shutting down backend...")


# ─── FastAPI App ──────────────────────────────────────────────────────────────

app = FastAPI(
    title="SMARANA Cognitive Wellness API",
    description="AI-Powered Cognitive Engagement & Memory Companion Platform (SIH 2026 PS 26003).",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list + ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Router Registration
app.include_router(auth_router)
app.include_router(games_router)
app.include_router(cognitive_router)
app.include_router(dashboard_router)
app.include_router(reminders_router)


# ─── System & WebSocket Endpoints ─────────────────────────────────────────────

@app.get("/")
def root():
    # In the hosted build, serve the React app from the same FastAPI service.
    index_file = Path(__file__).resolve().parent / "static" / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    return {
        "status": "online",
        "app": "SMARANA Cognitive Wellness Platform",
        "version": "1.0.0",
        "medical_safety_notice": "SMARANA is a cognitive engagement and monitoring tool, not a diagnostic or clinical device.",
    }


@app.get("/api/health")
def health_check():
    return {"status": "healthy", "database": "connected"}


# Serve the compiled React frontend when present (used by the free single-service deployment).
static_dir = Path(__file__).resolve().parent / "static"
if static_dir.exists():
    app.mount("/assets", StaticFiles(directory=static_dir / "assets"), name="assets")


@app.websocket("/ws/live")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_json()
            # Echo or broadcast incoming events
            await manager.broadcast({"type": "EVENT_ACK", "data": data})
    except WebSocketDisconnect:
        manager.disconnect(websocket)
