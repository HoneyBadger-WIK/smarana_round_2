"""
SMARANA Database Models — Full schema per Section 6 of the spec.
All tables keyed around the elder (patient) as the central hub.
"""

import datetime
from typing import Optional

from sqlalchemy import (
    String, Integer, Float, Boolean, DateTime, Text, ForeignKey,
    JSON, Enum as SAEnum, Index
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


# ─── Enums ──────────────────────────────────────────────────────────────────

import enum


class UserRole(str, enum.Enum):
    ELDER_USER = "elder_user"
    FAMILY_MEMBER = "family_member"
    HEALTHCARE_PROFESSIONAL = "healthcare_professional"
    ADMIN = "admin"


class ReminderType(str, enum.Enum):
    MEDICINE = "medicine"
    HYDRATION = "hydration"
    ACTIVITY = "activity"
    APPOINTMENT = "appointment"


class ReminderStatus(str, enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    MISSED = "missed"
    SNOOZED = "snoozed"


class VerificationStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class SyncStatus(str, enum.Enum):
    PENDING = "pending"
    SYNCED = "synced"
    FAILED = "failed"


class AlertSeverity(str, enum.Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class TrendDirection(str, enum.Enum):
    IMPROVING = "improving"
    STABLE = "stable"
    DECLINING = "declining"


# ─── Users & Profiles ──────────────────────────────────────────────────────


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    email: Mapped[Optional[str]] = mapped_column(String(255), unique=True, nullable=True)
    phone: Mapped[Optional[str]] = mapped_column(String(20), unique=True, nullable=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(50), default=UserRole.ELDER_USER.value)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )

    # Relationships
    elder_profile: Mapped[Optional["ElderProfile"]] = relationship(
        back_populates="user", uselist=False
    )
    healthcare_profile: Mapped[Optional["HealthcareProfessional"]] = relationship(
        back_populates="user", uselist=False
    )


class ElderProfile(Base):
    __tablename__ = "elder_profiles"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True)
    name: Mapped[str] = mapped_column(String(255))
    age: Mapped[int] = mapped_column(Integer)
    gender: Mapped[Optional[str]] = mapped_column(String(20))
    education_level: Mapped[Optional[str]] = mapped_column(String(50))
    primary_language: Mapped[str] = mapped_column(String(50), default="en")
    location: Mapped[Optional[str]] = mapped_column(String(255))
    avatar_id: Mapped[Optional[str]] = mapped_column(String(50))
    companion_name: Mapped[Optional[str]] = mapped_column(String(100))
    companion_type: Mapped[Optional[str]] = mapped_column(String(50))
    interests: Mapped[Optional[str]] = mapped_column(JSON, default=list)
    font_size: Mapped[str] = mapped_column(String(20), default="large")
    high_contrast: Mapped[bool] = mapped_column(Boolean, default=False)
    voice_first_mode: Mapped[bool] = mapped_column(Boolean, default=False)

    # Relationships
    user: Mapped["User"] = relationship(back_populates="elder_profile")
    game_sessions: Mapped[list["GameSession"]] = relationship(back_populates="patient")
    reminders: Mapped[list["Reminder"]] = relationship(back_populates="patient")
    mood_checkins: Mapped[list["MoodCheckin"]] = relationship(back_populates="patient")
    cognitive_metrics: Mapped[list["CognitiveMetric"]] = relationship(
        back_populates="patient"
    )
    streak: Mapped[Optional["Streak"]] = relationship(
        back_populates="patient", uselist=False
    )
    alerts: Mapped[list["Alert"]] = relationship(back_populates="patient")


class FamilyMember(Base):
    __tablename__ = "family_members"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    elder_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    name: Mapped[str] = mapped_column(String(255))
    relationship: Mapped[str] = mapped_column(String(100))
    permission_scope: Mapped[str] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )


class CaregiverPatient(Base):
    __tablename__ = "caregiver_patient"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    caregiver_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    relationship_type: Mapped[str] = mapped_column(String(100))
    granted_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    granted_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )


class HealthcareProfessional(Base):
    __tablename__ = "healthcare_professionals"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True)
    name: Mapped[str] = mapped_column(String(255))
    verification_status: Mapped[str] = mapped_column(
        String(20), default=VerificationStatus.PENDING.value
    )
    license_ref: Mapped[Optional[str]] = mapped_column(String(255))
    specialization: Mapped[Optional[str]] = mapped_column(String(255))

    user: Mapped["User"] = relationship(back_populates="healthcare_profile")


class PatientPanel(Base):
    __tablename__ = "patient_panel"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    healthcare_id: Mapped[int] = mapped_column(ForeignKey("healthcare_professionals.id"))
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    assigned_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )


# ─── Games & Sessions ──────────────────────────────────────────────────────


class GameType(Base):
    __tablename__ = "game_types"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)
    display_name: Mapped[str] = mapped_column(String(100))
    description: Mapped[Optional[str]] = mapped_column(Text)
    cognitive_domains: Mapped[str] = mapped_column(JSON, default=list)
    min_difficulty: Mapped[int] = mapped_column(Integer, default=1)
    max_difficulty: Mapped[int] = mapped_column(Integer, default=5)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class GameSession(Base):
    __tablename__ = "game_sessions"

    session_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    game_type_id: Mapped[int] = mapped_column(ForeignKey("game_types.id"))
    date: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )
    difficulty_level: Mapped[int] = mapped_column(Integer, default=1)
    game_duration_sec: Mapped[float] = mapped_column(Float, default=0)
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    hints_used: Mapped[int] = mapped_column(Integer, default=0)
    reaction_time_ms: Mapped[float] = mapped_column(Float, default=0)
    error_count: Mapped[int] = mapped_column(Integer, default=0)
    accuracy_percentage: Mapped[float] = mapped_column(Float, default=0)
    memory_score: Mapped[float] = mapped_column(Float, default=0)
    attention_span_sec: Mapped[float] = mapped_column(Float, default=0)
    recall_score: Mapped[float] = mapped_column(Float, default=0)
    pattern_recognition_score: Mapped[float] = mapped_column(Float, default=0)
    object_recognition_score: Mapped[float] = mapped_column(Float, default=0)

    # DDA output (stored for auditability)
    cpi_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    recommended_difficulty: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    recommendation_reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Relationships
    patient: Mapped["ElderProfile"] = relationship(back_populates="game_sessions")
    game_type: Mapped["GameType"] = relationship()

    __table_args__ = (
        Index("ix_sessions_patient_date", "patient_id", "date"),
        Index("ix_sessions_patient_game", "patient_id", "game_type_id"),
    )


class CognitiveMetric(Base):
    """Rolling cognitive domain metrics computed from game sessions."""
    __tablename__ = "cognitive_metrics"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    domain: Mapped[str] = mapped_column(String(50))  # e.g. "memory", "attention"
    current_score: Mapped[float] = mapped_column(Float, default=0)
    previous_score: Mapped[float] = mapped_column(Float, default=0)
    rolling_avg_recent: Mapped[float] = mapped_column(Float, default=0)
    rolling_avg_baseline: Mapped[float] = mapped_column(Float, default=0)
    trend_direction: Mapped[str] = mapped_column(
        String(20), default=TrendDirection.STABLE.value
    )
    percent_change: Mapped[float] = mapped_column(Float, default=0)
    last_calculated_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )

    patient: Mapped["ElderProfile"] = relationship(back_populates="cognitive_metrics")

    __table_args__ = (
        Index("ix_cognitive_patient_domain", "patient_id", "domain"),
    )


# ─── Reminders & Routines ──────────────────────────────────────────────────


class Reminder(Base):
    __tablename__ = "reminders"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    type: Mapped[str] = mapped_column(String(20))
    title: Mapped[str] = mapped_column(String(255))
    description: Mapped[Optional[str]] = mapped_column(Text)
    schedule_time: Mapped[Optional[str]] = mapped_column(String(10))  # HH:MM format
    schedule_days: Mapped[Optional[str]] = mapped_column(JSON, default=list)  # ["mon","tue",...]
    dosage: Mapped[Optional[str]] = mapped_column(String(100))
    instructions: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default=ReminderStatus.PENDING.value)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_completed_at: Mapped[Optional[datetime.datetime]] = mapped_column(
        DateTime, nullable=True
    )
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )

    patient: Mapped["ElderProfile"] = relationship(back_populates="reminders")


class DailyRoutine(Base):
    __tablename__ = "daily_routines"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    step_order: Mapped[int] = mapped_column(Integer)
    description: Mapped[str] = mapped_column(String(255))
    time_of_day: Mapped[Optional[str]] = mapped_column(String(20))
    caregiver_defined: Mapped[bool] = mapped_column(Boolean, default=True)


class Appointment(Base):
    __tablename__ = "appointments"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    doctor: Mapped[str] = mapped_column(String(255))
    date: Mapped[datetime.date] = mapped_column()
    time: Mapped[Optional[str]] = mapped_column(String(10))
    location: Mapped[Optional[str]] = mapped_column(String(255))
    notes: Mapped[Optional[str]] = mapped_column(Text)


class MoodCheckin(Base):
    __tablename__ = "mood_checkins"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    date: Mapped[datetime.date] = mapped_column()
    mood_value: Mapped[int] = mapped_column(Integer)  # 1-5 mapping to 😢😔😐🙂😊
    notes: Mapped[Optional[str]] = mapped_column(Text)

    patient: Mapped["ElderProfile"] = relationship(back_populates="mood_checkins")


# ─── Memory Graph & Capsule ────────────────────────────────────────────────


class MemoryGraphPerson(Base):
    __tablename__ = "memory_graph_people"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    name: Mapped[str] = mapped_column(String(255))
    relationship: Mapped[Optional[str]] = mapped_column(String(100))
    photo_url: Mapped[Optional[str]] = mapped_column(String(500))


class MemoryGraphEvent(Base):
    __tablename__ = "memory_graph_events"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    title: Mapped[str] = mapped_column(String(255))
    date: Mapped[Optional[datetime.date]] = mapped_column(nullable=True)
    description: Mapped[Optional[str]] = mapped_column(Text)
    related_people: Mapped[Optional[str]] = mapped_column(JSON, default=list)


class MemoryCapsuleItem(Base):
    __tablename__ = "memory_capsule_items"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    uploaded_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    type: Mapped[str] = mapped_column(String(20))  # photo, video, audio
    storage_url: Mapped[str] = mapped_column(String(500))
    caption: Mapped[Optional[str]] = mapped_column(Text)
    consent_scope: Mapped[str] = mapped_column(String(50), default="family")
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )


class LifeStoryEntry(Base):
    __tablename__ = "life_story_entries"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    prompt: Mapped[str] = mapped_column(Text)
    response_text: Mapped[Optional[str]] = mapped_column(Text)
    audio_url: Mapped[Optional[str]] = mapped_column(String(500))
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )


# ─── Gamification ──────────────────────────────────────────────────────────


class DailyJourneyTask(Base):
    __tablename__ = "daily_journey_tasks"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    date: Mapped[datetime.date] = mapped_column()
    task_type: Mapped[str] = mapped_column(String(50))
    task_title: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(20), default="pending")
    completed_at: Mapped[Optional[datetime.datetime]] = mapped_column(
        DateTime, nullable=True
    )


class Streak(Base):
    __tablename__ = "streaks"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(
        ForeignKey("elder_profiles.id"), unique=True
    )
    current_streak: Mapped[int] = mapped_column(Integer, default=0)
    longest_streak: Mapped[int] = mapped_column(Integer, default=0)
    last_active_date: Mapped[Optional[datetime.date]] = mapped_column(nullable=True)

    patient: Mapped["ElderProfile"] = relationship(back_populates="streak")


class Reward(Base):
    __tablename__ = "rewards"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    type: Mapped[str] = mapped_column(String(50))
    title: Mapped[str] = mapped_column(String(255))
    earned_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )


# ─── Alerts & Sync ─────────────────────────────────────────────────────────


class Alert(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    type: Mapped[str] = mapped_column(String(50))
    message: Mapped[str] = mapped_column(Text)
    severity: Mapped[str] = mapped_column(
        String(20), default=AlertSeverity.INFO.value
    )
    is_acknowledged: Mapped[bool] = mapped_column(Boolean, default=False)
    acknowledged_by: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id"), nullable=True
    )
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )

    patient: Mapped["ElderProfile"] = relationship(back_populates="alerts")


class SyncQueue(Base):
    __tablename__ = "sync_queue"

    sync_id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("elder_profiles.id"))
    entity_type: Mapped[str] = mapped_column(String(50))
    operation: Mapped[str] = mapped_column(String(20))  # create, update, delete
    payload: Mapped[str] = mapped_column(JSON)
    idempotency_key: Mapped[str] = mapped_column(String(100), unique=True)
    timestamp: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )
    sync_status: Mapped[str] = mapped_column(
        String(20), default=SyncStatus.PENDING.value
    )


# ─── System ─────────────────────────────────────────────────────────────────


class Language(Base):
    __tablename__ = "languages"

    code: Mapped[str] = mapped_column(String(10), primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    native_name: Mapped[Optional[str]] = mapped_column(String(100))
    has_offline_stt: Mapped[bool] = mapped_column(Boolean, default=False)
    has_offline_tts: Mapped[bool] = mapped_column(Boolean, default=False)


class CulturalContent(Base):
    __tablename__ = "cultural_content"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    region: Mapped[str] = mapped_column(String(100))
    language_code: Mapped[str] = mapped_column(String(10))
    category: Mapped[str] = mapped_column(String(50))
    title: Mapped[Optional[str]] = mapped_column(String(255))
    asset_url: Mapped[Optional[str]] = mapped_column(String(500))


class AuditLog(Base):
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(50))
    entity: Mapped[str] = mapped_column(String(50))
    entity_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    details: Mapped[Optional[str]] = mapped_column(JSON, nullable=True)
    timestamp: Mapped[datetime.datetime] = mapped_column(
        DateTime, default=datetime.datetime.utcnow
    )
