"""
SMARANA Dynamic Difficulty Adjustment (DDA) Engine

Implements the rule-based Composite Performance Index (CPI) computation
and adaptive difficulty recommendation per Section 3 of the spec.

CPI Formula:
  CPI = w1*Accuracy + w2*ReactionTime_norm + w3*MemoryScore 
        + w4*AttentionSpan_norm + w5*RecallScore + w6*ErrorPenalty

Rule Thresholds (per-difficulty, Section 3):
  - CPI ≥ 80 and error_rate ≤ 5%  → INCREASE difficulty
  - CPI ≤ 40 or error_rate ≥ 25%  → DECREASE difficulty
  - Otherwise                      → MAINTAIN difficulty

All outputs include explainability strings — never raw numbers to caregivers.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class DDAResult:
    """Result from the DDA engine with full explainability."""
    cpi_score: float
    current_difficulty: int
    recommended_difficulty: int
    direction: str  # "increase" | "decrease" | "maintain"
    reason: str
    domain_scores: dict[str, float]
    component_breakdown: dict[str, float]


# Weights for CPI components (must sum to 1.0)
CPI_WEIGHTS = {
    "accuracy": 0.25,
    "reaction_time_norm": 0.15,
    "memory_score": 0.20,
    "attention_span_norm": 0.15,
    "recall_score": 0.15,
    "error_penalty": 0.10,
}

# Rule thresholds
INCREASE_CPI_THRESHOLD = 80.0
INCREASE_ERROR_RATE_MAX = 5.0
DECREASE_CPI_THRESHOLD = 40.0
DECREASE_ERROR_RATE_MIN = 25.0

# Normalization caps
MAX_REACTION_TIME_MS = 5000.0  # 5s cap for normalization
MAX_ATTENTION_SPAN_SEC = 300.0  # 5min cap for normalization


def normalize_reaction_time(reaction_time_ms: float) -> float:
    """Normalize reaction time: faster is better → higher score."""
    clamped = min(max(reaction_time_ms, 0), MAX_REACTION_TIME_MS)
    return (1.0 - clamped / MAX_REACTION_TIME_MS) * 100.0


def normalize_attention_span(attention_span_sec: float) -> float:
    """Normalize attention span: longer is better → higher score."""
    clamped = min(max(attention_span_sec, 0), MAX_ATTENTION_SPAN_SEC)
    return (clamped / MAX_ATTENTION_SPAN_SEC) * 100.0


def compute_error_penalty(error_count: int, attempts: int) -> float:
    """
    Error penalty: lower errors → higher score.
    Score = (1 - error_rate) * 100
    """
    if attempts == 0:
        return 100.0  # No attempts → no errors
    error_rate = min(error_count / attempts, 1.0)
    return (1.0 - error_rate) * 100.0


def compute_error_rate(error_count: int, attempts: int) -> float:
    """Compute raw error rate as a percentage."""
    if attempts == 0:
        return 0.0
    return (error_count / attempts) * 100.0


def compute_cpi(
    accuracy: float,
    reaction_time_ms: float,
    memory_score: float,
    attention_span_sec: float,
    recall_score: float,
    error_count: int,
    attempts: int,
) -> tuple[float, dict[str, float]]:
    """
    Compute the Composite Performance Index.
    
    Returns:
        (cpi_score, component_breakdown) where component_breakdown 
        shows each weighted component for explainability.
    """
    rt_norm = normalize_reaction_time(reaction_time_ms)
    attn_norm = normalize_attention_span(attention_span_sec)
    err_penalty = compute_error_penalty(error_count, attempts)

    components = {
        "accuracy": accuracy,
        "reaction_time_norm": rt_norm,
        "memory_score": memory_score,
        "attention_span_norm": attn_norm,
        "recall_score": recall_score,
        "error_penalty": err_penalty,
    }

    weighted_components = {
        k: v * CPI_WEIGHTS[k] for k, v in components.items()
    }

    cpi = sum(weighted_components.values())
    # Clamp to 0-100
    cpi = min(max(cpi, 0), 100)

    return cpi, weighted_components


def get_recommendation(
    cpi_score: float,
    error_rate: float,
    current_difficulty: int,
    min_difficulty: int = 1,
    max_difficulty: int = 5,
) -> tuple[int, str, str]:
    """
    Apply rule-based thresholds to recommend difficulty.
    
    Returns:
        (recommended_difficulty, direction, reason)
    """
    if cpi_score >= INCREASE_CPI_THRESHOLD and error_rate <= INCREASE_ERROR_RATE_MAX:
        if current_difficulty < max_difficulty:
            return (
                current_difficulty + 1,
                "increase",
                f"Strong engagement detected! Performance index of {cpi_score:.0f}/100 "
                f"with only {error_rate:.1f}% error rate suggests readiness for "
                f"a more stimulating challenge (Level {current_difficulty} → {current_difficulty + 1})."
            )
        else:
            return (
                current_difficulty,
                "maintain",
                f"Excellent engagement at maximum challenge level! "
                f"Performance index: {cpi_score:.0f}/100. "
                f"Maintaining current level {current_difficulty}."
            )

    elif cpi_score <= DECREASE_CPI_THRESHOLD or error_rate >= DECREASE_ERROR_RATE_MIN:
        if current_difficulty > min_difficulty:
            reason_parts = []
            if cpi_score <= DECREASE_CPI_THRESHOLD:
                reason_parts.append(
                    f"engagement index is {cpi_score:.0f}/100 (below comfort threshold)"
                )
            if error_rate >= DECREASE_ERROR_RATE_MIN:
                reason_parts.append(
                    f"error rate of {error_rate:.1f}% suggests the current level may be challenging"
                )
            reason = (
                f"Adjusting to a more comfortable level to keep activities enjoyable. "
                f"{' and '.join(reason_parts).capitalize()}. "
                f"Moving from Level {current_difficulty} → {current_difficulty - 1}."
            )
            return (current_difficulty - 1, "decrease", reason)
        else:
            return (
                current_difficulty,
                "maintain",
                f"Maintaining the gentlest difficulty level. "
                f"The activities are designed to be enjoyable at every level."
            )

    else:
        return (
            current_difficulty,
            "maintain",
            f"Current difficulty level {current_difficulty} seems like a good fit! "
            f"Performance index: {cpi_score:.0f}/100 — keeping activities at this level."
        )


def evaluate_session(
    accuracy: float,
    reaction_time_ms: float,
    memory_score: float,
    attention_span_sec: float,
    recall_score: float,
    error_count: int,
    attempts: int,
    current_difficulty: int,
    min_difficulty: int = 1,
    max_difficulty: int = 5,
) -> DDAResult:
    """
    Full DDA pipeline: compute CPI → apply rules → return recommendation with explanation.
    
    This is the main entry point called by the API.
    """
    cpi_score, component_breakdown = compute_cpi(
        accuracy=accuracy,
        reaction_time_ms=reaction_time_ms,
        memory_score=memory_score,
        attention_span_sec=attention_span_sec,
        recall_score=recall_score,
        error_count=error_count,
        attempts=attempts,
    )

    error_rate = compute_error_rate(error_count, attempts)

    recommended_difficulty, direction, reason = get_recommendation(
        cpi_score=cpi_score,
        error_rate=error_rate,
        current_difficulty=current_difficulty,
        min_difficulty=min_difficulty,
        max_difficulty=max_difficulty,
    )

    domain_scores = {
        "memory": memory_score,
        "attention": normalize_attention_span(attention_span_sec),
        "recall": recall_score,
        "accuracy": accuracy,
        "reaction_speed": normalize_reaction_time(reaction_time_ms),
    }

    return DDAResult(
        cpi_score=round(cpi_score, 2),
        current_difficulty=current_difficulty,
        recommended_difficulty=recommended_difficulty,
        direction=direction,
        reason=reason,
        domain_scores={k: round(v, 2) for k, v in domain_scores.items()},
        component_breakdown={k: round(v, 4) for k, v in component_breakdown.items()},
    )
