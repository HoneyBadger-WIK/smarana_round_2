"""
SMARANA Cognitive Trends Service

Computes per-domain cognitive trends from game sessions using
rolling averages and change detection. Generates alerts for
significant changes.

All language is engagement-focused per medical safety constraints.
"""

import datetime
from typing import Optional

from sqlalchemy.orm import Session

from app.models.models import (
    GameSession, CognitiveMetric, Alert, AlertSeverity, TrendDirection
)


# Configuration
RECENT_WINDOW = 5       # Last N sessions for recent avg
BASELINE_WINDOW = 20    # Last N sessions for baseline avg
SIGNIFICANT_DECLINE_PERCENT = -15.0  # Trigger alert at 15% decline
SIGNIFICANT_IMPROVEMENT_PERCENT = 15.0


# Domain-to-column mappings
DOMAIN_COLUMN_MAP = {
    "memory": "memory_score",
    "attention": "attention_span_sec",
    "recall": "recall_score",
    "pattern_recognition": "pattern_recognition_score",
    "accuracy": "accuracy_percentage",
}


def compute_domain_trend(
    sessions: list[GameSession],
    domain: str,
) -> dict:
    """
    Compute trend for a cognitive domain from a list of sessions.
    
    Returns dict with:
      - current_score, previous_score
      - rolling_avg_recent, rolling_avg_baseline
      - trend_direction, percent_change
    """
    col = DOMAIN_COLUMN_MAP.get(domain)
    if not col or not sessions:
        return {
            "current_score": 0,
            "previous_score": 0,
            "rolling_avg_recent": 0,
            "rolling_avg_baseline": 0,
            "trend_direction": TrendDirection.STABLE.value,
            "percent_change": 0,
        }

    # Sort by date descending
    sorted_sessions = sorted(sessions, key=lambda s: s.date, reverse=True)
    scores = [getattr(s, col, 0) or 0 for s in sorted_sessions]

    current_score = scores[0] if scores else 0
    previous_score = scores[1] if len(scores) > 1 else current_score

    recent_scores = scores[:RECENT_WINDOW]
    baseline_scores = scores[:BASELINE_WINDOW]

    recent_avg = sum(recent_scores) / len(recent_scores) if recent_scores else 0
    baseline_avg = sum(baseline_scores) / len(baseline_scores) if baseline_scores else 0

    # Compute percent change relative to baseline
    if baseline_avg > 0:
        percent_change = ((recent_avg - baseline_avg) / baseline_avg) * 100
    else:
        percent_change = 0

    # Determine direction
    if percent_change >= SIGNIFICANT_IMPROVEMENT_PERCENT:
        direction = TrendDirection.IMPROVING.value
    elif percent_change <= SIGNIFICANT_DECLINE_PERCENT:
        direction = TrendDirection.DECLINING.value
    else:
        direction = TrendDirection.STABLE.value

    return {
        "current_score": round(current_score, 2),
        "previous_score": round(previous_score, 2),
        "rolling_avg_recent": round(recent_avg, 2),
        "rolling_avg_baseline": round(baseline_avg, 2),
        "trend_direction": direction,
        "percent_change": round(percent_change, 2),
    }


def update_cognitive_metrics(
    db: Session,
    patient_id: int,
) -> list[CognitiveMetric]:
    """
    Recompute all cognitive domain metrics for a patient from their sessions.
    Called after every new game session.
    """
    sessions = (
        db.query(GameSession)
        .filter(GameSession.patient_id == patient_id)
        .order_by(GameSession.date.desc())
        .limit(BASELINE_WINDOW)
        .all()
    )

    results = []
    for domain in DOMAIN_COLUMN_MAP:
        trend = compute_domain_trend(sessions, domain)

        # Upsert the metric
        metric = (
            db.query(CognitiveMetric)
            .filter(
                CognitiveMetric.patient_id == patient_id,
                CognitiveMetric.domain == domain,
            )
            .first()
        )

        if metric is None:
            metric = CognitiveMetric(patient_id=patient_id, domain=domain)
            db.add(metric)

        metric.current_score = trend["current_score"]
        metric.previous_score = trend["previous_score"]
        metric.rolling_avg_recent = trend["rolling_avg_recent"]
        metric.rolling_avg_baseline = trend["rolling_avg_baseline"]
        metric.trend_direction = trend["trend_direction"]
        metric.percent_change = trend["percent_change"]
        metric.last_calculated_at = datetime.datetime.utcnow()

        results.append(metric)

        # Check for alert-worthy changes
        if trend["trend_direction"] == TrendDirection.DECLINING.value:
            _create_trend_alert(db, patient_id, domain, trend)

    db.commit()
    return results


def _create_trend_alert(
    db: Session,
    patient_id: int,
    domain: str,
    trend: dict,
):
    """
    Create an engagement trend alert (never diagnostic language).
    Only creates if no recent unacknowledged alert exists for this domain.
    """
    # Check for existing unacknowledged alert
    recent_alert = (
        db.query(Alert)
        .filter(
            Alert.patient_id == patient_id,
            Alert.type == f"trend_{domain}",
            Alert.is_acknowledged == False,
        )
        .first()
    )

    if recent_alert:
        return  # Don't duplicate

    # Engagement-framed message (never diagnostic)
    message = (
        f"Engagement pattern change detected in {domain.replace('_', ' ')} activities. "
        f"Recent engagement level is {abs(trend['percent_change']):.0f}% below the "
        f"usual range. This may simply reflect daily variation. "
        f"Consider adjusting activity levels or encouraging a favourite activity."
    )

    severity = (
        AlertSeverity.WARNING.value
        if trend["percent_change"] <= -25
        else AlertSeverity.INFO.value
    )

    alert = Alert(
        patient_id=patient_id,
        type=f"trend_{domain}",
        message=message,
        severity=severity,
    )
    db.add(alert)
