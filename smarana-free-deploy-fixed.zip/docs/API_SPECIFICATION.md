# SMARANA API Specification

## Auth Endpoints (`/api/v1/auth`)

### `POST /api/v1/auth/signup`
- **Description**: Registers a new user with a specified role (`PATIENT`, `CAREGIVER`, `DOCTOR`, `ADMIN`).
- **Request Body**:
  ```json
  {
    "email": "user@example.com",
    "password": "securepassword123",
    "full_name": "Anandi Sharma",
    "role": "PATIENT"
  }
  ```
- **Response**: `201 Created` with created user details.

### `POST /api/v1/auth/login`
- **Description**: Authenticates user and returns JWT bearer token.
- **Request Body**:
  ```json
  {
    "email": "user@example.com",
    "password": "securepassword123"
  }
  ```
- **Response**: `200 OK`
  ```json
  {
    "access_token": "<jwt_string>",
    "token_type": "bearer"
  }
  ```

### `GET /api/v1/auth/me`
- **Description**: Returns current authenticated user profile.
- **Header**: `Authorization: Bearer <jwt_string>`

---

## Games & DDA Endpoints (`/api/v1/games`)

### `POST /api/v1/games/session`
- **Description**: Records a completed cognitive game session and calculates recommended difficulty for next session.
- **Request Body**:
  ```json
  {
    "game_type": "memory_matrix",
    "score": 850,
    "reaction_time_ms": 1200,
    "accuracy": 0.92,
    "session_duration_s": 180,
    "mistake_count": 2,
    "current_dda_level": 3
  }
  ```
- **Response**:
  ```json
  {
    "session_id": "uuid",
    "recommended_dda_level": 4,
    "feedback": "Great focus! Difficulty adjusted for optimal engagement."
  }
  ```

---

## Dashboard Telemetry WebSocket (`/ws/live`)
- **Protocol**: `ws://<host>/ws/live`
- **Message Format**:
  ```json
  {
    "patient_id": "p-1029",
    "patient_name": "Anandi Sharma",
    "status": "active_game",
    "current_game": "Memory Matrix (Level 4)",
    "battery_level": 88,
    "last_heartbeat": "14:30:15",
    "today_sessions_count": 3
  }
  ```
