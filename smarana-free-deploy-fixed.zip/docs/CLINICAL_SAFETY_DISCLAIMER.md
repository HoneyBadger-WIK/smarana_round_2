# SMARANA Clinical Safety & Ethical Compliance Framework

## 1. Non-Diagnostic Medical Statement
SMARANA is designed as an assistive digital health and cognitive wellness companion platform for elderly individuals and family caregivers. **It is explicitly non-diagnostic.**

- **Scope**: Memory engagement games, routine reminders, voice-assisted family memory anchor prompts, and caregiver telemetry.
- **Exclusion**: SMARANA does not provide clinical medical diagnosis, disease staging (e.g. MMSE score evaluation for clinical mild cognitive impairment stage), or pharmacological prescription advice.

## 2. Terminology Guidelines
All output metrics within the software applications, APIs, and web dashboards adhere to standard wellness framing:

| Prohibited Clinical Term | Approved SMARANA Terminology |
| :--- | :--- |
| Dementia Stage | Cognitive Engagement Level |
| Brain Deterioration | Reaction Time & Recall Pattern |
| Disease Risk Assessment | Wellness Session Frequency |
| Patient Deficit | Cognitive Training Focus Area |

## 3. Privacy & Offline Security
- User cognitive logs and memory vault items remain encrypted on local device storage (SQLite/Hive).
- Biometric and EEG signals (when integrated with research datasets like MCSAD) are normalized into power spectral densities without persisting sensitive identifiable metrics.
