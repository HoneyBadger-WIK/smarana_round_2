# SMARANA Platform Architecture & Design Document

## Executive Overview
**SMARANA (स्मरण)** is an AI-powered cognitive wellness and memory companion platform designed for elderly individuals and early-stage cognitive care (SIH 2026, PS 26003).

### Key Architectural Principles
1. **Offline-First Architecture**: Local-first storage utilizing SQLite and Flame/Flutter engine ensuring uninterrupted operational access in low-connectivity areas (such as North Eastern Region of India).
2. **Deterministic & Adaptive Difficulty Adjustment (DDA)**: Hybrid model leveraging a rule-based expert system with a machine learning (`RandomForestClassifier`) engine to dynamically adjust cognitive game parameters based on user accuracy and reaction time.
3. **Strict Non-Diagnostic Framing**: All cognitive metrics, EEG signal summaries, and performance statistics are strictly framed as **"Engagement & Cognitive Wellness"** indicators rather than diagnostic medical conclusions.
4. **Multi-Role RBAC**: Granular role-based access control supporting `PATIENT`, `CAREGIVER`, `DOCTOR`, and `ADMIN` profiles.

---

## Architecture Diagram

```mermaid
graph TD
    subgraph Client Tier
        Mobile[Flutter App / Flame Engine]
        Web[React Web Dashboard]
    end

    subgraph Service Tier (FastAPI Backend)
        AuthService[JWT & Auth Router]
        GamesService[Cognitive Games Router]
        DDAEngine[DDA ML & Rule Engine]
        TelemetryService[WebSocket Live Status Manager]
        IntegrationService[LLM / Voice / Telephony Fallback Abstractions]
    end

    subgraph Data & Storage Tier
        LocalDB[(SQLite Local Storage)]
        MLModel[(dda_model.joblib)]
        Dataset[(MCSAD EEG & Dementia Data)]
    end

    Mobile -->|REST API / Offline Sync| AuthService
    Mobile -->|Game Sessions| GamesService
    Web -->|WebSocket Telemetry| TelemetryService
    GamesService --> DDAEngine
    DDAEngine --> MLModel
    AuthService --> LocalDB
```

---

## Core Components

### 1. Adaptive Difficulty Engine (DDA)
- **Inputs**: `reaction_time_ms`, `accuracy_rate`, `session_duration_s`, `mistake_count`.
- **Logic**:
  - **Rule-Based Engine**: Baseline calculation enforcing upper/lower thresholds (Level 1 to 5).
  - **ML Engine**: Scikit-Learn `RandomForestClassifier` trained on normalized cognitive datasets.
  - **Resilience**: Automatic fallback to rule-based logic if ML model features or artifacts are unavailable.

### 2. Multi-Role Web Dashboard
- Built with React 18, Vite, TypeScript, and Tailwind CSS.
- Integrates Recharts for cognitive performance trends and DDA difficulty level transitions.
- Subscribes to `/ws/live` WebSocket channel with fallback telemetry simulation for network resilience.

### 3. Clinical & Regulatory Disclaimers
- Non-diagnostic warning banners rendered across all specialist and caregiver views.
- Adheres to medical safety protocols avoiding diagnostic labels such as "Alzheimer's stage" or "dementia diagnosis".
