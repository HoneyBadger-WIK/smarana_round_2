import os
import time
import sys

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)
import sounddevice as sd
from scipy.io.wavfile import write

from voice.stt import transcribe_audio
from voice.tts import speak

from voice_assitant.intelligence.intent import (
    detect_intent,
    get_response,
)

from voice_assitant.intelligence.conversation import (
    ConversationEngine,
)


# ============================================================
# CONFIGURATION
# ============================================================

SAMPLE_RATE = 16000
RECORD_SECONDS = 15

PROJECT_ROOT = os.path.dirname(
    os.path.dirname(os.path.abspath(__file__))
)

AUDIO_FILE = os.path.join(
    PROJECT_ROOT,
    "input.wav"
)


# ============================================================
# CONVERSATION ENGINE
# ============================================================

conversation = ConversationEngine()


# ============================================================
# RECORD AUDIO
# ============================================================

def record_audio():
    """
    Record microphone input and save it as WAV.
    """

    print("\n🎤 Recording...")

    audio = sd.rec(
        int(RECORD_SECONDS * SAMPLE_RATE),
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype="int16",
    )

    sd.wait()

    write(
        AUDIO_FILE,
        SAMPLE_RATE,
        audio,
    )


# ============================================================
# MEMORY GAME
# ============================================================

def start_memory_game():

    print("\n🧠 Starting memory game...")

    print(
        "\nRemember these objects:"
    )

    print(
        "🥭 Mango"
    )

    print(
        "🚲 Bicycle"
    )

    print(
        "🌸 Flower"
    )

    print(
        "\nGame logic will be added here."
    )


# ============================================================
# HANDLE INTENT
# ============================================================

def handle_intent(
    intent: str,
    user_text: str,
):

    print(
        f"\nDetected intent: {intent}"
    )

    # --------------------------------------------------------
    # GET BASIC RESPONSE
    # --------------------------------------------------------

    response = get_response(intent)

    # --------------------------------------------------------
    # PROCESS THROUGH CONVERSATION ENGINE
    # --------------------------------------------------------

    reply = conversation.process(
        user_text=user_text,
        intent=intent,
        response=response,
    )

    print(
        f"Assistant: {reply}"
    )

    speak(reply)

    # --------------------------------------------------------
    # START MEMORY GAME
    # --------------------------------------------------------

    if intent == "START_GAME":

        conversation.start_game()

        start_memory_game()

        return

    # --------------------------------------------------------
    # STOP MEMORY GAME
    # --------------------------------------------------------

    if intent == "STOP_GAME":

        if conversation.game_is_active():

            conversation.stop_game()

            print(
                "\n🛑 Memory game stopped."
            )

        else:

            print(
                "\nNo game is currently running."
            )

        return


# ============================================================
# START ASSISTANT
# ============================================================

print("\n" + "=" * 55)

print(
    "        SMARANA VOICE ASSISTANT"
)

print("=" * 55)

print(
    "\nVoice assistant ready."
)

print(
    "Speak after each recording starts."
)

print(
    "Say 'exit' or 'stop listening' to quit."
)

print("=" * 55)


# ============================================================
# MAIN LOOP
# ============================================================

try:

    while True:

        try:

            # ---------------------------------------------
            # RECORD
            # ---------------------------------------------

            record_audio()


            # ---------------------------------------------
            # TRANSCRIBE
            # ---------------------------------------------

            text = transcribe_audio()

            print(
                "\nYou said:"
            )

            print(
                f'"{text}"'
            )


            # ---------------------------------------------
            # EMPTY INPUT
            # ---------------------------------------------

            if not text:

                print(
                    "No speech detected."
                )

                continue


            # ---------------------------------------------
            # EXIT COMMAND
            # ---------------------------------------------

            text_lower = text.lower()

            exit_commands = [
                "exit",
                "stop listening",
                "shutdown",
            ]

            if any(
                command in text_lower
                for command in exit_commands
            ):

                print(
                    "\nShutting down. Goodbye."
                )

                speak(
                    "Goodbye. Take care."
                )

                break


            # ---------------------------------------------
            # DETECT INTENT
            # ---------------------------------------------

            intent = detect_intent(text)


            # ---------------------------------------------
            # HANDLE INTENT
            # ---------------------------------------------

            handle_intent(
                intent,
                text,
            )


            # ---------------------------------------------
            # SMALL PAUSE
            # ---------------------------------------------

            time.sleep(0.5)


        except KeyboardInterrupt:

            print(
                "\n\nInterrupted by user."
            )

            break


        except Exception as error:

            print(
                f"\n[ERROR] {error}"
            )

            print(
                "The assistant will continue..."
            )

            time.sleep(1)


finally:

    # ---------------------------------------------
    # CLEAN UP AUDIO FILE
    # ---------------------------------------------

    if os.path.exists(AUDIO_FILE):

        os.remove(AUDIO_FILE)

    print(
        "\nSmārana stopped."
    )