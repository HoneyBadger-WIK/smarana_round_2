# ============================================================
# SMARANA ADAPTIVE MEMORY GAME
# ============================================================

import random
import time


class MemoryGame:
    def __init__(self, difficulty="easy"):
        self.difficulty = difficulty
        self.objects = []
        self.score = 0
        self.round_number = 0
        self.round_history = []

        self.object_pool = [
            "mango",
            "bicycle",
            "flower",
            "book",
            "umbrella",
            "apple",
            "chair",
            "clock",
            "river",
            "tree",
        ]

    def get_object_count(self):
        if self.difficulty == "easy":
            return 3
        if self.difficulty == "medium":
            return 5
        if self.difficulty == "hard":
            return 7

        return 3

    def create_round(self):
        count = self.get_object_count()

        self.objects = random.sample(
            self.object_pool,
            count
        )

        self.round_number += 1

        return self.objects

    def show_objects(self):
        print("\n🧠 Remember these objects:\n")

        for index, obj in enumerate(self.objects, start=1):
            print(f"{index}. {obj.title()}")

        print("\nRemember them carefully...")

        time.sleep(3)

        print("\n" + "=" * 40)
        print("The objects are now hidden.")

    def check_answer(self, answer: str):
        answer = answer.lower().strip()

        remembered = []

        for obj in self.objects:
            if obj in answer:
                remembered.append(obj)

        correct = len(remembered)
        total = len(self.objects)

        score_percentage = (
            correct / total * 100
            if total > 0
            else 0
        )

        self.score += correct

        result = {
            "round": self.round_number,
            "correct": correct,
            "total": total,
            "percentage": score_percentage,
            "remembered": remembered,
            "difficulty": self.difficulty,
        }

        self.round_history.append(result)

        return result

    def adapt_difficulty(self, percentage):
        old_difficulty = self.difficulty

        if self.difficulty == "easy" and percentage >= 80:
            self.difficulty = "medium"

        elif self.difficulty == "medium" and percentage >= 80:
            self.difficulty = "hard"

        elif self.difficulty == "hard" and percentage < 50:
            self.difficulty = "medium"

        elif self.difficulty == "medium" and percentage < 40:
            self.difficulty = "easy"

        if old_difficulty != self.difficulty:
            print(
                f"\n📈 Difficulty changed: "
                f"{old_difficulty} → {self.difficulty}"
            )

        return self.difficulty

    def start_round(self):
        self.create_round()
        self.show_objects()

    def get_status(self):
        return {
            "difficulty": self.difficulty,
            "round": self.round_number,
            "score": self.score,
            "history": self.round_history,
        }
