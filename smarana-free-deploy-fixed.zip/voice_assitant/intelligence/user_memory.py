class UserMemory:
    def __init__(self):
        self.name = None
        self.preferred_language = "en"
        self.favorite_topics = []
        self.family_members = []
        self.important_places = []

    def set_name(self, name):
        self.name = name

    def get_name(self):
        return self.name