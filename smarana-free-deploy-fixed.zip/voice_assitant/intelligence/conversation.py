# ============================================================
# SMARANA CONVERSATION ENGINE
# ============================================================

from voice_assitant.intelligence.context import ConversationContext


class ConversationEngine:

    def __init__(self):
        self.context = ConversationContext()

    # ========================================================
    # PROCESS USER MESSAGE
    # ========================================================

    def process(self, user_text: str, intent: str, response: str):

        user_text = user_text.strip()

        # Update conversation memory
        self.context.update(
            user_text=user_text,
            intent=intent,
            response=response,
        )

        # Return the response
        return response

    # ========================================================
    # GET CURRENT CONTEXT
    # ========================================================

    def get_context(self):

        return self.context.get_context()

    # ========================================================
    # GAME STATE
    # ========================================================

    def start_game(self):

        self.context.start_game()

    def stop_game(self):

        self.context.stop_game()

    # ========================================================
    # CHECK IF GAME IS ACTIVE
    # ========================================================

    def game_is_active(self):

        return self.context.game_active

    # ========================================================
    # RESET CONVERSATION
    # ========================================================

    def reset(self):

        self.context.clear()
