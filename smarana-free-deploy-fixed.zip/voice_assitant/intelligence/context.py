# ============================================================
# SMARANA CONVERSATION CONTEXT
# ============================================================

class ConversationContext:
    """
    Stores short-term conversation information.

    This allows Smārana to remember what was happening
    during the current conversation.
    """

    def __init__(self):

        # Last thing the user said
        self.last_user_text = ""

        # Last intent detected
        self.last_intent = "UNKNOWN"

        # Last response given by Smārana
        self.last_response = ""

        # Current activity
        self.current_activity = None

        # Whether a game is currently running
        self.game_active = False

    # ========================================================
    # UPDATE CONTEXT
    # ========================================================

    def update(
        self,
        user_text: str,
        intent: str,
        response: str,
    ):

        self.last_user_text = user_text
        self.last_intent = intent
        self.last_response = response

    # ========================================================
    # GAME STATE
    # ========================================================

    def start_game(self):

        self.game_active = True
        self.current_activity = "memory_game"

    def stop_game(self):

        self.game_active = False
        self.current_activity = None

    # ========================================================
    # CONTEXT SUMMARY
    # ========================================================

    def get_context(self) -> dict:

        return {
            "last_user_text": self.last_user_text,
            "last_intent": self.last_intent,
            "last_response": self.last_response,
            "current_activity": self.current_activity,
            "game_active": self.game_active,
        }

    # ========================================================
    # CLEAR CONTEXT
    # ========================================================

    def clear(self):

        self.last_user_text = ""
        self.last_intent = "UNKNOWN"
        self.last_response = ""
        self.current_activity = None
        self.game_active = False
