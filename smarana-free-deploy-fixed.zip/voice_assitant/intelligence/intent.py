# ============================================================
# SMARANA INTENT ENGINE
# ============================================================

import re


# ============================================================
# INTENTS
# ============================================================

INTENTS = {

    # --------------------------------------------------------
    # GAMES
    # --------------------------------------------------------

    "START_GAME": [
        "start game",
        "start a game",
        "play a game",
        "play game",
        "memory game",
        "start memory",
        "play memory",
        "let's play",
        "lets play",
        "i want to play",
        "i'd like to play",
        "can we play",
        "can you start a game",
        "start playing",
    ],

    "STOP_GAME": [
        "stop game",
        "end game",
        "quit game",
        "stop playing",
        "stop the game",
        "end the game",
        "i want to stop",
    ],

    # --------------------------------------------------------
    # SCHEDULE
    # --------------------------------------------------------

    "SCHEDULE": [
        "schedule",
        "what do i have",
        "what am i doing today",
        "what is my schedule",
        "today's schedule",
        "todays schedule",
        "my activities",
        "my schedule",
        "show my schedule",
        "tell me my schedule",
        "what is planned today",
        "what do i have today",
    ],

    # --------------------------------------------------------
    # REMINDERS
    # --------------------------------------------------------

    "REMINDER": [
        "remind me",
        "reminder",
        "reminders",
        "what are my reminders",
        "show my reminders",
        "check my reminders",
        "medicine",
        "medication",
        "appointment",
        "appointments",
        "what do i need to remember",
    ],

    # --------------------------------------------------------
    # PROGRESS
    # --------------------------------------------------------

    "PROGRESS": [
        "my progress",
        "how did i do",
        "my score",
        "show my score",
        "how am i doing",
        "how did i perform",
        "my performance",
        "show my progress",
        "check my progress",
        "how have i been doing",
    ],

    # --------------------------------------------------------
    # CONVERSATION
    # --------------------------------------------------------

    "GREETING": [
        "hello",
        "hi",
        "hey",
        "good morning",
        "good afternoon",
        "good evening",
        "hello smarana",
        "hi smarana",
        "hey smarana",
    ],

    "HOW_ARE_YOU": [
        "how are you",
        "how are you doing",
        "how are things",
        "how have you been",
        "are you doing well",
        "are you okay",
        "how do you feel",
    ],

    "THANKS": [
        "thank you",
        "thanks",
        "thank you so much",
        "thanks a lot",
        "i appreciate it",
    ],

    "GOODBYE": [
        "goodbye",
        "bye",
        "see you",
        "see you later",
        "good night",
    ],

    "NAME": [
        "what is your name",
        "what's your name",
        "who are you",
        "tell me your name",
        "what should i call you",
    ],
}


# ============================================================
# INTENT PRIORITY
# ============================================================

# Higher number = more important when scores are similar.
INTENT_PRIORITY = {

    "STOP_GAME": 100,
    "START_GAME": 90,

    "REMINDER": 80,
    "SCHEDULE": 70,
    "PROGRESS": 60,

    "NAME": 50,
    "HOW_ARE_YOU": 40,
    "GREETING": 30,
    "THANKS": 20,
    "GOODBYE": 10,
}


# ============================================================
# RESPONSES
# ============================================================

RESPONSES = {

    "GREETING":
        "Hello! It's nice to hear from you. How are you doing?",

    "HOW_ARE_YOU":
        "I'm doing fine, thank you! How are you doing?",

    "THANKS":
        "You're very welcome!",

    "GOODBYE":
        "Goodbye! Take care and have a wonderful day.",

    "NAME":
        "I'm Smārana, your voice assistant. I'm here to help you.",

    "START_GAME":
        "Okay. Starting your memory game now.",

    "STOP_GAME":
        "Okay, stopping the game.",

    "SCHEDULE":
        "Let me check your schedule for today.",

    "REMINDER":
        "Let me check your reminders.",

    "PROGRESS":
        "Let me check how you are doing.",

    "UNKNOWN":
        "I'm sorry, I didn't quite understand that. Could you say it again?",
}


# ============================================================
# TEXT NORMALIZATION
# ============================================================

def normalize_text(text: str) -> str:
    """
    Normalize transcribed speech before intent detection.
    """

    text = text.lower().strip()

    # Remove punctuation.
    text = re.sub(r"[^\w\s']", " ", text)

    # Collapse multiple spaces.
    text = re.sub(r"\s+", " ", text)

    return text


# ============================================================
# DETECT INTENT
# ============================================================

def detect_intent(text: str) -> str:
    """
    Detect the most likely intent from transcribed speech.

    Uses keyword scoring rather than returning the first
    matching keyword.
    """

    text = normalize_text(text)

    if not text:
        return "UNKNOWN"

    scores = {}

    for intent, keywords in INTENTS.items():

        score = 0

        for keyword in keywords:

            keyword = normalize_text(keyword)

            if re.search(r"\b" + re.escape(keyword) + r"\b", text):
                # Longer phrases are more specific,
                # so give them a higher score.
                score += len(keyword.split()) * 10

                # Exact match gets an additional bonus.
                if text == keyword:
                    score += 50

        if score > 0:
            scores[intent] = score

    if not scores:
        return "UNKNOWN"

    # Select highest score.
    best_intent = max(
        scores,
        key=lambda intent: (
            scores[intent],
            INTENT_PRIORITY.get(intent, 0)
        )
    )

    return best_intent


# ============================================================
# GET RESPONSE
# ============================================================

def get_response(intent: str) -> str:
    """
    Return the default response for an intent.
    """

    return RESPONSES.get(
        intent,
        RESPONSES["UNKNOWN"],
    )


# ============================================================
# DEBUG HELPER
# ============================================================

def explain_intent(text: str) -> dict:
    """
    Useful during development.

    Shows the detected intent and normalized text.
    """

    normalized = normalize_text(text)
    intent = detect_intent(text)

    return {
        "original": text,
        "normalized": normalized,
        "intent": intent,
    }