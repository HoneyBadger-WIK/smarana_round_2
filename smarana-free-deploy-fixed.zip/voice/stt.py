import os

from faster_whisper import WhisperModel


# ============================================================
# CONFIGURATION
# ============================================================

WHISPER_MODEL = "small"
WHISPER_DEVICE = "cpu"
WHISPER_COMPUTE_TYPE = "int8"

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AUDIO_FILE = os.path.join(PROJECT_ROOT, "input.wav")


# ============================================================
# WHISPER MODEL
# ============================================================

print("🧠 Loading Whisper speech recognition model...")

model = WhisperModel(
    WHISPER_MODEL,
    device=WHISPER_DEVICE,
    compute_type=WHISPER_COMPUTE_TYPE,
)

print("✓ Whisper model loaded.")


# ============================================================
# SPEECH TO TEXT
# ============================================================

def transcribe_audio(audio_file: str = AUDIO_FILE) -> str:
    """
    Convert recorded audio into English text using Whisper.
    """

    print("🧠 Processing speech...")

    try:

        segments, info = model.transcribe(
            audio_file,
            beam_size=5,
            language="en",
            vad_filter=True,
        )

        text = " ".join(
            segment.text
            for segment in segments
        )

        return text.strip()

    except Exception as error:

        print(f"\n[STT ERROR] {error}")

        return ""


# ============================================================
# TEST MODE
# ============================================================

if __name__ == "__main__":

    if not os.path.exists(AUDIO_FILE):

        print(
            f"❌ Audio file not found: {AUDIO_FILE}"
        )

        print(
            "Create input.wav first, then run this file again."
        )

    else:

        result = transcribe_audio(AUDIO_FILE)

        print("\nYou said:")
        print(f'"{result}"')
