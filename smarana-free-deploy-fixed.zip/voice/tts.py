import os
from dotenv import load_dotenv
from elevenlabs.client import ElevenLabs
from elevenlabs.play import play
load_dotenv()

# ============================================================
# CONFIGURATION
# ============================================================

ELEVENLABS_VOICE_ID = "EXAVITQu4vr4xnSDxMaL"  # Sarah
ELEVENLABS_MODEL = "eleven_turbo_v2_5"


# ============================================================
# INITIALIZE ELEVENLABS
# ============================================================

api_key = os.environ.get("ELEVENLABS_API_KEY")

if not api_key:
    raise RuntimeError(
        "ELEVENLABS_API_KEY environment variable is not set."
    )

eleven = ElevenLabs(api_key=api_key)


# ============================================================
# TEXT TO SPEECH
# ============================================================

def speak(text: str):
    """
    Convert text to speech using ElevenLabs
    and play the generated audio.
    """

    if not text:
        return

    try:

        audio = eleven.text_to_speech.convert(
            text=text,
            voice_id=ELEVENLABS_VOICE_ID,
            model_id=ELEVENLABS_MODEL,
        )

        play(audio)

    except Exception as error:

        print(f"\n[TTS ERROR] {error}")
        print("Continuing without voice output...\n")


# ============================================================
# TEST MODE
# ============================================================

if __name__ == "__main__":

    print("🔊 Testing Smārana text-to-speech...")

    speak(
        "Hello. This is Smārana. "
        "Your voice assistant is working correctly."
    )

    print("✓ TTS test complete.")
