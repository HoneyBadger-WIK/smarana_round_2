import React, { useEffect, useState } from 'react';
import { CognitiveTrend, GameSession, LivePatientStatus, MemoryCapsule, RoutineTask, UserRole } from './types';
import { apiService } from './services/api';
import { liveSocket } from './services/websocket';
import { Header } from './components/Header';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { OverviewDashboard } from './views/OverviewDashboard';
import { CaregiverPortal } from './views/CaregiverPortal';
import { ClinicalView } from './views/ClinicalView';
import { MemoryVaultView } from './views/MemoryVaultView';
import { RoutineChecklist } from './components/RoutineChecklist';

export const App: React.FC = () => {
  const [currentRole, setRole] = useState<UserRole>('CARETAKER');
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');

  const [liveStatus, setLiveStatus] = useState<LivePatientStatus | null>(null);
  const [trends, setTrends] = useState<CognitiveTrend[]>([]);
  const [tasks, setTasks] = useState<RoutineTask[]>([]);
  const [capsules, setCapsules] = useState<MemoryCapsule[]>([]);
  const [sessions, setSessions] = useState<GameSession[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const loadData = async () => {
    try {
      setLoading(true);
      const [tData, rData, mData, sData] = await Promise.all([
        apiService.fetchCognitiveTrends(),
        apiService.fetchRoutines(),
        apiService.fetchMemoryCapsules(),
        apiService.fetchGameSessions(),
      ]);
      setTrends(tData);
      setTasks(rData);
      setCapsules(mData);
      setSessions(sData);
    } catch (e) {
      console.error('[SMARANA App] Error loading dashboard data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    // Connect WebSocket
    liveSocket.connect();
    const unsubscribe = liveSocket.subscribe((status) => {
      setLiveStatus(status);
    });

    return () => {
      unsubscribe();
      liveSocket.disconnect();
    };
  }, []);

  const handleToggleTask = (id: string) => {
    setTasks(prev => prev.map(task => 
      task.id === id ? { ...task, is_completed: !task.is_completed } : task
    ));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <Header currentRole={currentRole} setRole={setRole} onRefresh={loadData} />

      <div className="flex-1 flex overflow-hidden">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
          {activeTab === 'overview' && (
            <OverviewDashboard
              liveStatus={liveStatus}
              trends={trends}
              tasks={tasks}
              capsules={capsules}
              sessions={sessions}
              onToggleTask={handleToggleTask}
            />
          )}

          {activeTab === 'caregiver' && (
            <CaregiverPortal
              liveStatus={liveStatus}
              tasks={tasks}
              sessions={sessions}
              onToggleTask={handleToggleTask}
            />
          )}

          {activeTab === 'clinical' && (
            <ClinicalView
              trends={trends}
              sessions={sessions}
            />
          )}

          {activeTab === 'vault' && (
            <MemoryVaultView
              capsules={capsules}
            />
          )}

          {activeTab === 'routines' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-white">Daily Routine & Medication Schedule</h2>
              <RoutineChecklist tasks={tasks} onToggleTask={handleToggleTask} />
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default App;
