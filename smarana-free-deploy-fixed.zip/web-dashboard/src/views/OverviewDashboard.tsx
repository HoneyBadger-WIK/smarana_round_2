import React from 'react';
import { CognitiveTrend, GameSession, LivePatientStatus, MemoryCapsule, RoutineTask } from '../types';
import { DisclaimerBanner } from '../components/DisclaimerBanner';
import { LiveStatusWidget } from '../components/LiveStatusWidget';
import { CognitiveCharts } from '../components/CognitiveCharts';
import { RoutineChecklist } from '../components/RoutineChecklist';
import { MemoryCapsuleGallery } from '../components/MemoryCapsuleGallery';
import { Brain, Sparkles, Activity, ShieldCheck, Heart } from 'lucide-react';

interface OverviewDashboardProps {
  liveStatus: LivePatientStatus | null;
  trends: CognitiveTrend[];
  tasks: RoutineTask[];
  capsules: MemoryCapsule[];
  sessions: GameSession[];
  onToggleTask: (id: string) => void;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  liveStatus,
  trends,
  tasks,
  capsules,
  sessions,
  onToggleTask,
}) => {
  return (
    <div className="space-y-6">
      <DisclaimerBanner />

      {/* Hero Welcome & Telemetry */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-2xl font-bold text-white tracking-tight font-outfit flex items-center gap-2">
              Namaste, Anandi Ji! 🙏
            </h2>
            <p className="text-sm text-slate-400">Welcome to your daily memory companion space.</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-3 py-1.5 rounded-xl bg-teal-500/10 text-teal-300 border border-teal-500/20 text-xs font-semibold flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-teal-400" />
              Streak: 12 Days Active
            </span>
          </div>
        </div>

        <LiveStatusWidget status={liveStatus} />
      </div>

      {/* Metrics Highlights Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-card p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold">Weekly Engagement</span>
            <Brain className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-2xl font-bold text-white font-outfit">94.2 %</div>
          <p className="text-[11px] text-emerald-400 font-medium">Consistent daily activity</p>
        </div>

        <div className="glass-card p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold">Active Memory Anchors</span>
            <Heart className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold text-white font-outfit">{capsules.length} Capsules</div>
          <p className="text-[11px] text-purple-300">Used in association games</p>
        </div>

        <div className="glass-card p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold">DDA Adaptive Level</span>
            <Activity className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white font-outfit">Level 4</div>
          <p className="text-[11px] text-amber-300">Optimal stimulation mode</p>
        </div>

        <div className="glass-card p-4 space-y-2">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold">Privacy Protection</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-outfit">100% On-Device</div>
          <p className="text-[11px] text-slate-400">Offline SQLite database</p>
        </div>
      </div>

      {/* Main Charts & Routines Row */}
      <CognitiveCharts trends={trends} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <MemoryCapsuleGallery capsules={capsules} />
        </div>
        <div className="lg:col-span-1">
          <RoutineChecklist tasks={tasks} onToggleTask={onToggleTask} />
        </div>
      </div>
    </div>
  );
};
