import React from 'react';
import { CognitiveTrend, GameSession } from '../types';
import { DisclaimerBanner } from '../components/DisclaimerBanner';
import { CognitiveCharts } from '../components/CognitiveCharts';
import { EEGSummaryCard } from '../components/EEGSummaryCard';
import { EEGExplanationCard } from '../components/EEGExplanationCard';
import { GameSessionHistory } from '../components/GameSessionHistory';
import { Activity, Download, FileText } from 'lucide-react';

interface ClinicalViewProps {
  trends: CognitiveTrend[];
  sessions: GameSession[];
}

export const ClinicalView: React.FC<ClinicalViewProps> = ({ trends, sessions }) => {
  return (
    <div className="space-y-6">
      <DisclaimerBanner />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-6 h-6 text-teal-600" />
            <h2 className="text-xl font-bold text-slate-800 font-outfit">
              Clinical & Specialist Engagement Analytics
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Non-diagnostic sensor trends, game performance metrics, and machine learning DDA engine parameters
          </p>
        </div>

        <button
          onClick={() => alert('Generating Non-Diagnostic PDF Summary Report...')}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-50 hover:bg-teal-100 border border-teal-200 text-teal-800 text-xs font-semibold transition-all cursor-pointer shadow-xs"
        >
          <Download className="w-4 h-4 text-teal-600" />
          Export Non-Diagnostic Summary (PDF)
        </button>
      </div>

      {/* EEG Educational Explanation Card answering what the spectral bands represent */}
      <EEGExplanationCard />

      {/* EEG Live Telemetry Summary */}
      <EEGSummaryCard />

      {/* Weekly Trends Chart */}
      <CognitiveCharts trends={trends} />

      {/* Detailed Game Session Logs */}
      <GameSessionHistory sessions={sessions} />
    </div>
  );
};
