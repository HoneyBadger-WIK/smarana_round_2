import React, { useState, useEffect } from 'react';
import { GameSession, LivePatientStatus, PatientInfo, RoutineTask } from '../types';
import { apiService } from '../services/api';
import { DisclaimerBanner } from '../components/DisclaimerBanner';
import { LiveStatusWidget } from '../components/LiveStatusWidget';
import { GameSessionHistory } from '../components/GameSessionHistory';
import { RoutineChecklist } from '../components/RoutineChecklist';
import { HeartPulse, Bell, PhoneCall, CheckCircle, UserCheck, Users, Battery, MapPin, Activity, AlertCircle } from 'lucide-react';

interface CaregiverPortalProps {
  liveStatus: LivePatientStatus | null;
  tasks: RoutineTask[];
  sessions: GameSession[];
  onToggleTask: (id: string) => void;
}

export const CaregiverPortal: React.FC<CaregiverPortalProps> = ({
  liveStatus,
  tasks,
  sessions,
  onToggleTask,
}) => {
  const [patients, setPatients] = useState<PatientInfo[]>([]);
  const [selectedPatientId, setSelectedPatientId] = useState<string>('p-101');
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchPatientsList = async () => {
      try {
        const data = await apiService.fetchPatients();
        setPatients(data);
      } catch (err) {
        console.error('Error fetching patients:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchPatientsList();
  }, []);

  const selectedPatient = patients.find((p) => p.id === selectedPatientId) || patients[0];

  return (
    <div className="space-y-6">
      <DisclaimerBanner />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <HeartPulse className="w-6 h-6 text-teal-600" />
            <h2 className="text-xl font-bold text-slate-800 font-outfit">
              Caretaker & Family Telemetry Portal
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Multi-patient live oversight, daily routine completion, and cognitive session monitoring
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => alert(`Triggering emergency safety check call for ${selectedPatient?.name || 'patient'}!`)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold transition-all cursor-pointer shadow-xs"
          >
            <PhoneCall className="w-4 h-4 text-rose-600" />
            Trigger Emergency Call
          </button>
        </div>
      </div>

      {/* Multi-Patient Selector Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-700 flex items-center gap-2 font-outfit">
            <Users className="w-4 h-4 text-teal-600" />
            Assigned Senior Patients ({patients.length})
          </h3>
          <span className="text-xs text-slate-400">Click to select and view patient dashboard</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {patients.map((patient) => {
            const isSelected = patient.id === selectedPatientId;
            let riskBadgeClass = 'bg-emerald-100 text-emerald-800 border-emerald-300';
            if (patient.risk_status === 'attention_needed') {
              riskBadgeClass = 'bg-amber-100 text-amber-800 border-amber-300';
            } else if (patient.risk_status === 'optimal') {
              riskBadgeClass = 'bg-teal-100 text-teal-800 border-teal-300';
            }

            return (
              <div
                key={patient.id}
                onClick={() => setSelectedPatientId(patient.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-3 shadow-xs ${
                  isSelected
                    ? 'bg-gradient-to-br from-teal-50/90 to-emerald-50/90 border-2 border-teal-500 shadow-md scale-102'
                    : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-800 font-bold flex items-center justify-center text-xs font-outfit">
                      {patient.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-800 line-clamp-1">{patient.name}</h4>
                      <p className="text-[10px] text-slate-500 flex items-center gap-1">
                        <MapPin className="w-2.5 h-2.5" /> {patient.location}
                      </p>
                    </div>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${riskBadgeClass}`}>
                    {patient.risk_status.replace('_', ' ')}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-slate-200/60">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Routines</span>
                    <span className="font-semibold text-slate-700">
                      {patient.routines_completed} / {patient.total_routines} Done
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Battery</span>
                    <span className="font-semibold text-slate-700 flex items-center gap-1">
                      <Battery className="w-3 h-3 text-emerald-600" /> {patient.battery_level}%
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Patient Live Telemetry Overview */}
      {selectedPatient && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <span className="text-xs text-teal-600 font-semibold uppercase tracking-wider">Active Monitoring Overview</span>
              <h3 className="text-lg font-bold text-slate-800 font-outfit">{selectedPatient.name} (Age {selectedPatient.age})</h3>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs bg-slate-100 text-slate-700 px-3 py-1 rounded-full font-medium">
                Last Active: {selectedPatient.last_active}
              </span>
            </div>
          </div>

          <LiveStatusWidget
            status={
              liveStatus || {
                patient_id: selectedPatient.id,
                patient_name: selectedPatient.name,
                status: selectedPatient.status,
                current_game: selectedPatient.current_game,
                battery_level: selectedPatient.battery_level,
                last_heartbeat: selectedPatient.last_active,
                today_sessions_count: 3,
              }
            }
          />
        </div>
      )}

      {/* Caregiver Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 border-l-4 border-l-teal-500 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Daily Routine Completion</span>
            <CheckCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold text-slate-800 font-outfit">
            {tasks.filter((t) => t.is_completed).length} of {tasks.length} Completed
          </div>
          <p className="text-[11px] text-teal-700 font-medium">Medication & morning Tea done</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 border-l-4 border-l-purple-500 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Cognitive Play Time</span>
            <UserCheck className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-xl font-bold text-slate-800 font-outfit">35 Minutes Today</div>
          <p className="text-[11px] text-purple-700 font-medium">Memory Matrix & Mahjong</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 border-l-4 border-l-emerald-500 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Safety Status</span>
            <Bell className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold text-emerald-600 font-outfit">0 Active Warnings</div>
          <p className="text-[11px] text-slate-500">All routines operating normally</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <RoutineChecklist tasks={tasks} onToggleTask={onToggleTask} />
        <GameSessionHistory sessions={sessions} />
      </div>
    </div>
  );
};
