import React, { useState } from 'react';
import { Gamepad2, Brain, Sparkles, Layers, BookOpen, Activity, Zap, Play, ArrowLeft } from 'lucide-react';
import { MemoryCardGame } from '../components/games/MemoryCardGame';
import { TilePuzzleGame } from '../components/games/TilePuzzleGame';
import { MahjongGame } from '../components/games/MahjongGame';
import { WordAssociationGame } from '../components/games/WordAssociationGame';
import { PatternSequenceGame } from '../components/games/PatternSequenceGame';
import { ColorStroopGame } from '../components/games/ColorStroopGame';

export type GameKey = 'memory' | 'puzzle' | 'mahjong' | 'word' | 'pattern' | 'stroop' | null;

interface GamesSuiteViewProps {
  initialGame?: GameKey;
}

export const GamesSuiteView: React.FC<GamesSuiteViewProps> = ({ initialGame = null }) => {
  const [selectedGame, setSelectedGame] = useState<GameKey>(initialGame);

  const gamesCatalog = [
    {
      id: 'memory' as GameKey,
      title: 'Memory Card Match',
      category: 'Recall & Recognition',
      description: 'Match pairs of traditional items & symbols to build working memory',
      icon: Brain,
      color: 'teal',
      badge: 'Game 1',
      bgClass: 'hover:border-teal-400 bg-teal-50/40',
      badgeClass: 'bg-teal-100 text-teal-700',
    },
    {
      id: 'puzzle' as GameKey,
      title: '3x3 Tile Sliding Puzzle',
      category: 'Spatial Reasoning',
      description: 'Arrange tiles numerical order to strengthen visual-spatial processing',
      icon: Layers,
      color: 'purple',
      badge: 'Game 2',
      bgClass: 'hover:border-purple-400 bg-purple-50/40',
      badgeClass: 'bg-purple-100 text-purple-700',
    },
    {
      id: 'mahjong' as GameKey,
      title: 'Mahjong Pair Solitaire',
      category: 'Visual Perception',
      description: 'Find matching unblocked Mahjong tiles to enhance visual focus',
      icon: Sparkles,
      color: 'emerald',
      badge: 'Game 3',
      bgClass: 'hover:border-emerald-400 bg-emerald-50/40',
      badgeClass: 'bg-emerald-100 text-emerald-700',
    },
    {
      id: 'word' as GameKey,
      title: 'Word Association & Recall',
      category: 'Semantic Language',
      description: 'Connect cultural concepts and recall semantic word pairs',
      icon: BookOpen,
      color: 'amber',
      badge: 'Game 4',
      bgClass: 'hover:border-amber-400 bg-amber-50/40',
      badgeClass: 'bg-amber-100 text-amber-700',
    },
    {
      id: 'pattern' as GameKey,
      title: 'Color Pattern Sequence',
      category: 'Sequential Memory',
      description: 'Watch light patterns and repeat sequences to expand working memory',
      icon: Activity,
      color: 'sky',
      badge: 'Game 5',
      bgClass: 'hover:border-sky-400 bg-sky-50/40',
      badgeClass: 'bg-sky-100 text-sky-700',
    },
    {
      id: 'stroop' as GameKey,
      title: 'Color Stroop Challenge',
      category: 'Inhibitory Control',
      description: 'Identify ink color ignoring word text to sharpen cognitive flexibility',
      icon: Zap,
      color: 'rose',
      badge: 'Game 6',
      bgClass: 'hover:border-rose-400 bg-rose-50/40',
      badgeClass: 'bg-rose-100 text-rose-700',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-slate-200 p-6 rounded-2xl shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-6 h-6 text-teal-600" />
            <h2 className="text-2xl font-bold text-slate-800 font-outfit">Adaptive Cognitive Games Suite</h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            6 specialized, non-diagnostic cognitive exercises designed for daily senior engagement & neurological stimulation
          </p>
        </div>

        {selectedGame && (
          <button
            onClick={() => setSelectedGame(null)}
            className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-medium text-xs transition-colors self-start sm:self-auto cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Game Selection
          </button>
        )}
      </div>

      {!selectedGame ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {gamesCatalog.map((g) => {
            const Icon = g.icon;
            return (
              <div
                key={g.id}
                onClick={() => setSelectedGame(g.id)}
                className={`border border-slate-200/90 rounded-2xl p-6 transition-all duration-300 cursor-pointer shadow-xs hover:shadow-md flex flex-col justify-between space-y-4 group ${g.bgClass}`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${g.badgeClass}`}>
                      {g.badge}
                    </span>
                    <span className="text-[11px] font-medium text-slate-400">{g.category}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Icon className="w-5 h-5 text-slate-700" />
                    </div>
                    <h3 className="text-lg font-bold text-slate-800 font-outfit group-hover:text-teal-700 transition-colors">
                      {g.title}
                    </h3>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">{g.description}</p>
                </div>

                <button className="w-full py-2.5 bg-white border border-slate-200 group-hover:border-teal-500 group-hover:bg-teal-600 group-hover:text-white text-slate-700 font-semibold text-xs rounded-xl flex items-center justify-center gap-2 transition-all">
                  <Play className="w-3.5 h-3.5" /> Launch Game
                </button>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="animate-fade-in">
          {selectedGame === 'memory' && <MemoryCardGame />}
          {selectedGame === 'puzzle' && <TilePuzzleGame />}
          {selectedGame === 'mahjong' && <MahjongGame />}
          {selectedGame === 'word' && <WordAssociationGame />}
          {selectedGame === 'pattern' && <PatternSequenceGame />}
          {selectedGame === 'stroop' && <ColorStroopGame />}
        </div>
      )}
    </div>
  );
};
