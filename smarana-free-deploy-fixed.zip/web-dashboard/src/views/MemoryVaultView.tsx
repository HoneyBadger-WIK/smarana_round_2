import React from 'react';
import { MemoryCapsule } from '../types';
import { MemoryCapsuleGallery } from '../components/MemoryCapsuleGallery';
import { Image, Upload, Search, Filter } from 'lucide-react';

interface MemoryVaultViewProps {
  capsules: MemoryCapsule[];
}

export const MemoryVaultView: React.FC<MemoryVaultViewProps> = ({ capsules }) => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Image className="w-6 h-6 text-teal-400" />
            Reminiscence Vault & Memory Tag Manager
          </h2>
          <p className="text-xs text-slate-400">Curate photo memories, family tags, and voice prompt anchors for therapeutic recall exercises</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search memories..."
              className="pl-9 pr-4 py-1.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-teal-500"
            />
          </div>
        </div>
      </div>

      <MemoryCapsuleGallery capsules={capsules} />
    </div>
  );
};
