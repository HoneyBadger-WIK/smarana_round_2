export type UserRole = 'PATIENT' | 'FAMILY' | 'CARETAKER';

export interface PatientInfo {
  id: string;
  name: string;
  age: number;
  location: string;
  status: 'active_game' | 'idle' | 'resting' | 'sos_triggered';
  current_game?: string;
  battery_level: number;
  last_active: string;
  routines_completed: number;
  total_routines: number;
  dda_level: number;
  risk_status: 'stable' | 'attention_needed' | 'optimal';
}

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  created_at?: string;
}

export interface CognitiveTrend {
  date: string;
  engagementScore: number;
  memoryMatrixScore: number;
  patternRecallScore: number;
  wordAssocScore: number;
  ddaDifficultyLevel: number;
}

export interface GameSession {
  id: string;
  game_type: 'memory_card' | 'tile_puzzle' | 'mahjong' | 'word_association' | 'pattern_sequence' | 'color_stroop';
  score: number;
  reaction_time_ms: number;
  accuracy: number;
  dda_level_applied: number;
  created_at: string;
}

export interface MemoryCapsule {
  id: string;
  title: string;
  description: string;
  category: 'family' | 'travel' | 'childhood' | 'milestone';
  media_url?: string;
  created_at: string;
  tag_count?: number;
}

export interface RoutineTask {
  id: string;
  title: string;
  time: string;
  category: 'medication' | 'exercise' | 'social' | 'memory';
  is_completed: boolean;
}

export interface LivePatientStatus {
  patient_id: string;
  patient_name: string;
  status: 'active_game' | 'idle' | 'resting' | 'sos_triggered';
  current_game?: string;
  battery_level: number;
  last_heartbeat: string;
  today_sessions_count: number;
}
