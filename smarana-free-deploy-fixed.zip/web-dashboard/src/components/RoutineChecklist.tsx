import React from 'react';
import { RoutineTask } from '../types';
import { CheckCircle2, Circle, Clock, Pill, Dumbbell, Users, Brain } from 'lucide-react';

interface RoutineChecklistProps {
  tasks: RoutineTask[];
  onToggleTask?: (id: string) => void;
}

export const RoutineChecklist: React.FC<RoutineChecklistProps> = ({ tasks, onToggleTask }) => {
  const getCategoryIcon = (category: RoutineTask['category']) => {
    switch (category) {
      case 'medication': return <Pill className="w-4 h-4 text-emerald-400" />;
      case 'exercise': return <Dumbbell className="w-4 h-4 text-blue-400" />;
      case 'social': return <Users className="w-4 h-4 text-purple-400" />;
      case 'memory': return <Brain className="w-4 h-4 text-teal-400" />;
      default: return <Clock className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="glass-panel p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-teal-400" />
            Daily Care & Routine Schedule
          </h3>
          <p className="text-xs text-slate-400">Scheduled reminders, medication, and memory engagement sessions</p>
        </div>

        <div className="text-xs text-slate-400">
          Completed: <strong className="text-teal-400">{tasks.filter(t => t.is_completed).length}/{tasks.length}</strong>
        </div>
      </div>

      <div className="space-y-2">
        {tasks.map((task) => (
          <div
            key={task.id}
            onClick={() => onToggleTask && onToggleTask(task.id)}
            className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
              task.is_completed
                ? 'bg-slate-900/30 border-slate-800/60 text-slate-400'
                : 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-teal-500/40'
            }`}
          >
            <div className="flex items-center gap-3">
              <button className="text-teal-400 focus:outline-none">
                {task.is_completed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <Circle className="w-5 h-5 text-slate-500" />
                )}
              </button>

              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-slate-800 border border-slate-700">
                  {getCategoryIcon(task.category)}
                </div>
                <span className={`text-sm font-medium ${task.is_completed ? 'line-through text-slate-500' : 'text-slate-100'}`}>
                  {task.title}
                </span>
              </div>
            </div>

            <span className="text-xs font-mono text-slate-400 px-2.5 py-1 rounded-md bg-slate-950 border border-slate-800">
              {task.time}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
