import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Volume2, Send, X, Bot, User, Brain, Play } from 'lucide-react';

interface AIVoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectGame?: (gameId: string) => void;
  onSelectTab?: (tab: string) => void;
}

interface Message {
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  actionGameId?: string;
}

export const AIVoiceAssistantModal: React.FC<AIVoiceAssistantModalProps> = ({
  isOpen,
  onClose,
  onSelectGame,
  onSelectTab,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [inputText, setInputText] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'assistant',
      text: 'Namaste! I am Smarana Sahayak (स्मरण सहायक). Ask me to play any of our 6 cognitive games, check your medicine schedule, or explain your EEG brainwave bands!',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  if (!isOpen) return null;

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const samplePrompts = [
    { label: '🀄 Play Mahjong Solitaire', text: 'I want to play Mahjong game', gameId: 'mahjong' },
    { label: '🧠 Play Memory Match', text: 'Start memory card match game', gameId: 'memory' },
    { label: '🧩 Play Tile Puzzle', text: 'Launch 3x3 tile puzzle', gameId: 'puzzle' },
    { label: '📚 Word Association', text: 'Play word association game', gameId: 'word' },
    { label: '⏰ Check Routines', text: 'What are my medicine reminders today?' },
    { label: '🌊 Explain EEG Bands', text: 'Explain the EEG spectral bands' },
  ];

  const handleSend = (textToSend?: string, directGameId?: string) => {
    const text = textToSend || inputText;
    if (!text.trim()) return;

    const newMsg: Message = {
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputText('');

    // Process intent
    setTimeout(() => {
      let reply = "I've logged your request! Everything is synchronized with your daily companion profile.";
      const lower = text.toLowerCase();

      if (lower.includes('mahjong')) {
        reply = 'Opening Mahjong Solitaire tile pair game for you now! Enjoy your session.';
        if (onSelectGame) onSelectGame('mahjong');
      } else if (lower.includes('memory')) {
        reply = 'Opening Memory Card Match game! Flip cards and match pairs to sharpen your focus.';
        if (onSelectGame) onSelectGame('memory');
      } else if (lower.includes('puzzle') || lower.includes('tile')) {
        reply = 'Starting 3x3 Tile Puzzle! Slide tiles into order to enhance spatial recall.';
        if (onSelectGame) onSelectGame('puzzle');
      } else if (lower.includes('word') || lower.includes('association')) {
        reply = 'Launching Word Association & Recall challenge!';
        if (onSelectGame) onSelectGame('word');
      } else if (lower.includes('pattern') || lower.includes('sequence')) {
        reply = 'Starting Color Pattern Sequence game!';
        if (onSelectGame) onSelectGame('pattern');
      } else if (lower.includes('stroop') || lower.includes('color')) {
        reply = 'Opening Color Stroop challenge! Match ink colors to boost cognitive agility.';
        if (onSelectGame) onSelectGame('stroop');
      } else if (lower.includes('medicine') || lower.includes('routine')) {
        reply = 'Your 07:30 AM Herbal Tea & 09:00 AM Memory Session are complete! Afternoon prescription medicine is set for 01:30 PM.';
        if (onSelectTab) onSelectTab('routines');
      } else if (lower.includes('eeg') || lower.includes('band') || lower.includes('delta') || lower.includes('alpha')) {
        reply = 'EEG bands track relaxation and cognitive focus: Delta (sleep/recovery), Theta (deep relaxation), Alpha (calm alertness), Beta (active focus), and Gamma (high cognition). All framed purely as non-diagnostic wellness insights!';
        if (onSelectTab) onSelectTab('clinical');
      }

      setMessages((prev) => [
        ...prev,
        {
          sender: 'assistant',
          text: reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          actionGameId: directGameId,
        },
      ]);
      speakText(reply);
    }, 600);
  };

  const toggleMic = () => {
    if (!isListening) {
      setIsListening(true);
      setTimeout(() => {
        setIsListening(false);
        handleSend('Play Mahjong Solitaire tile game');
      }, 3000);
    } else {
      setIsListening(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-3xl shadow-2xl w-full max-w-xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-teal-600 to-emerald-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base font-outfit">Smarana Sahayak (स्मरण सहायक)</h3>
              <p className="text-xs text-teal-100 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse"></span>
                AI Voice Companion & Voice Game Launcher
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Conversation Body */}
        <div className="p-4 flex-1 overflow-y-auto space-y-3 bg-slate-50">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-2.5 ${m.sender === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 font-bold text-xs ${
                  m.sender === 'user'
                    ? 'bg-teal-600 text-white'
                    : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                }`}
              >
                {m.sender === 'user' ? <User className="w-4 h-4" /> : <Brain className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[80%] p-3.5 rounded-2xl text-xs space-y-1 ${
                  m.sender === 'user'
                    ? 'bg-teal-600 text-white rounded-tr-none shadow-xs'
                    : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none shadow-xs'
                }`}
              >
                <p className="leading-relaxed text-sm">{m.text}</p>
                <span className={`text-[10px] block ${m.sender === 'user' ? 'text-teal-200 text-right' : 'text-slate-400'}`}>
                  {m.timestamp}
                </span>
              </div>
            </div>
          ))}

          {/* Voice Wave Animation */}
          {(isSpeaking || isListening) && (
            <div className="p-3 bg-teal-50 border border-teal-200 rounded-2xl flex items-center justify-center gap-1 text-teal-700 text-xs">
              <span className="font-semibold mr-2">{isListening ? 'Listening to voice...' : 'Smarana speaking...'}</span>
              <span className="w-1.5 h-6 bg-teal-600 rounded-full animate-pulse"></span>
              <span className="w-1.5 h-8 bg-teal-500 rounded-full animate-pulse delay-75"></span>
              <span className="w-1.5 h-4 bg-teal-400 rounded-full animate-pulse delay-150"></span>
            </div>
          )}
        </div>

        {/* Quick Sample Prompts */}
        <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 overflow-x-auto">
          {samplePrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p.text, p.gameId)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-teal-50 hover:text-teal-700 hover:border-teal-300 border border-slate-200 text-xs font-medium text-slate-700 whitespace-nowrap transition-all cursor-pointer"
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Input Controls */}
        <div className="p-4 bg-white border-t border-slate-200 flex items-center gap-3">
          <button
            onClick={toggleMic}
            className={`p-3 rounded-2xl transition-all cursor-pointer ${
              isListening
                ? 'bg-rose-600 text-white animate-pulse shadow-lg shadow-rose-600/30'
                : 'bg-teal-100 text-teal-700 hover:bg-teal-200 border border-teal-300'
            }`}
            title={isListening ? 'Stop Listening' : 'Speak to Voice Assistant'}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your question or click mic to speak..."
            className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-teal-500 focus:bg-white"
          />

          <button
            onClick={() => handleSend()}
            className="p-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white shadow-md transition-all cursor-pointer"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
