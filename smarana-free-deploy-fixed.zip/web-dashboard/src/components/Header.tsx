import React from 'react';
import { UserRole } from '../types';
import { Brain, Bell, User as UserIcon, Shield, RefreshCw, Bot, Sparkles } from 'lucide-react';

interface HeaderProps {
  currentRole: UserRole;
  setRole: (role: UserRole) => void;
  onRefresh?: () => void;
  onOpenAiAssistant?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  setRole,
  onRefresh,
  onOpenAiAssistant,
}) => {
  return (
    <header className="border-b border-slate-200/80 bg-white/90 backdrop-blur-md sticky top-0 z-40 px-4 sm:px-6 py-3.5 flex items-center justify-between shadow-xs">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-teal-600 to-emerald-500 flex items-center justify-center shadow-md shadow-teal-500/20">
          <Brain className="w-6 h-6 text-white stroke-[2.2]" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold tracking-tight text-slate-900 font-outfit">SMARANA</h1>
            <span className="text-[10px] font-mono tracking-wider px-2 py-0.5 rounded-md bg-teal-50 text-teal-700 border border-teal-200 uppercase font-bold">
              SIH 2026
            </span>
          </div>
          <p className="text-xs text-slate-500 font-sans hidden sm:block">Cognitive Wellness & Memory Companion</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* AI Voice Assistant Trigger */}
        <button
          onClick={onOpenAiAssistant}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-teal-50 to-emerald-50 hover:from-teal-100 hover:to-emerald-100 border border-teal-200/80 text-teal-800 text-xs font-bold transition-all shadow-xs cursor-pointer"
        >
          <Bot className="w-4 h-4 text-teal-600" />
          <span className="hidden md:inline">AI Companion</span>
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500"></span>
          </span>
        </button>

        {onRefresh && (
          <button
            onClick={onRefresh}
            className="p-2 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition-colors"
            title="Refresh Data"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        )}

        {/* Role Selector Switcher */}
        <div className="flex items-center bg-slate-100 border border-slate-200 rounded-xl p-1 text-xs">
          <Shield className="w-3.5 h-3.5 text-teal-600 ml-2 mr-1 hidden sm:block" />
          {(['PATIENT', 'FAMILY', 'CARETAKER'] as UserRole[]).map((r) => (
            <button
              key={r}
              onClick={() => setRole(r)}
              className={`px-3 py-1 rounded-lg transition-all font-semibold ${
                currentRole === r
                  ? 'bg-white text-teal-800 shadow-xs border border-slate-200/80'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              {r === 'CARETAKER' ? 'Caretaker' : r === 'FAMILY' ? 'Family' : 'Senior'}
            </button>
          ))}
        </div>

        <div className="relative p-2 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 hover:text-slate-900 cursor-pointer transition-colors">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-teal-500"></span>
        </div>

        <div className="flex items-center gap-2.5 pl-2 border-l border-slate-200">
          <div className="w-8 h-8 rounded-full bg-teal-100 border border-teal-300 flex items-center justify-center text-teal-800 font-bold text-xs">
            A
          </div>
          <div className="hidden lg:block">
            <p className="text-xs font-bold text-slate-800">Anandi Sharma</p>
            <p className="text-[10px] text-slate-500 capitalize">{currentRole.toLowerCase()}</p>
          </div>
        </div>
      </div>
    </header>
  );
};
