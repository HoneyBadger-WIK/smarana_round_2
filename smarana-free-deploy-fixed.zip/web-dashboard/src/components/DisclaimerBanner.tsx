import React from 'react';
import { ShieldAlert } from 'lucide-react';

export const DisclaimerBanner: React.FC = () => {
  return (
    <div className="bg-amber-950/40 border border-amber-500/30 rounded-xl p-3.5 flex items-center gap-3 text-amber-200 text-xs sm:text-sm">
      <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0" />
      <div>
        <span className="font-semibold text-amber-300">Non-Diagnostic Wellness Platform:</span> SMARANA provides cognitive engagement metrics and memory assistance. Data displayed does not constitute clinical diagnostic conclusions or medical treatment.
      </div>
    </div>
  );
};
