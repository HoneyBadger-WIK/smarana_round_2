import React from 'react';
import { Activity, Brain, Info, HelpCircle } from 'lucide-react';

export const EEGExplanationCard: React.FC = () => {
  const bands = [
    {
      name: 'Alpha Band (8–12 Hz)',
      state: 'Calm Focus & Peaceful Alertness',
      color: 'bg-emerald-500 text-white',
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
      description: 'Dominant when the mind is relaxed, calm, and ready to absorb information. In SMARANA games, high Alpha indicates comfortable engagement without stress.',
    },
    {
      name: 'Beta Band (12–30 Hz)',
      state: 'Active Thinking & Problem Solving',
      color: 'bg-teal-600 text-white',
      badgeColor: 'bg-teal-100 text-teal-800 border-teal-300',
      description: 'Active during active problem-solving (e.g. Mahjong tile matching, puzzle solving, word recall). Indicates active mental processing.',
    },
    {
      name: 'Theta Band (4–8 Hz)',
      state: 'Deep Relaxation & Memory Processing',
      color: 'bg-indigo-500 text-white',
      badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-300',
      description: 'Associated with deep relaxation, memory access, and creative daydreaming. Higher levels during reminiscence photo exercises reflect memory activation.',
    },
    {
      name: 'Delta Band (0.5–4 Hz)',
      state: 'Resting & Baseline State',
      color: 'bg-amber-500 text-white',
      badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
      description: 'Slowest brainwave frequency present during deep restful states or baseline resting conditions.',
    },
  ];

  return (
    <div className="glass-panel-light p-6 space-y-5 border-l-4 border-l-teal-600">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-teal-600" />
            <h3 className="text-lg font-bold text-slate-900">What are EEG Brainwave Bands?</h3>
          </div>
          <p className="text-xs text-slate-600 mt-1">
            Simple guide explaining electrical signal frequencies measured during cognitive wellness exercises.
          </p>
        </div>
        <span className="px-3 py-1 bg-teal-50 text-teal-700 font-semibold text-xs rounded-full border border-teal-200 flex items-center gap-1">
          <HelpCircle className="w-3.5 h-3.5" /> Non-Diagnostic Educational Guide
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {bands.map((band, idx) => (
          <div key={idx} className="p-4 rounded-xl bg-slate-50 border border-slate-200/90 space-y-2 hover:border-teal-300 transition-colors">
            <div className="flex items-center justify-between">
              <span className={`px-2.5 py-0.5 rounded-md text-xs font-bold border ${band.badgeColor}`}>
                {band.name}
              </span>
              <span className="text-[11px] font-semibold text-slate-500">{band.state}</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed pt-1">
              {band.description}
            </p>
          </div>
        ))}
      </div>

      <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-center gap-2">
        <Info className="w-4 h-4 text-amber-600 shrink-0" />
        <span>
          <strong>How SMARANA uses this:</strong> Signal features from research datasets (like MCSAD) help fine-tune game difficulty dynamically so exercises remain engaging without causing mental fatigue.
        </span>
      </div>
    </div>
  );
};
