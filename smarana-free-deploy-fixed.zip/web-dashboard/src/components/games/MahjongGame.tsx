import React, { useState, useEffect } from 'react';
import { RotateCcw, Award, Layers, Sparkles } from 'lucide-react';

interface Tile {
  id: number;
  symbol: string;
  type: string;
  isMatched: boolean;
}

const TILE_PAIRS = [
  { symbol: '🀀', type: 'East Wind' },
  { symbol: '🀁', type: 'South Wind' },
  { symbol: '🀂', type: 'West Wind' },
  { symbol: '🀃', type: 'North Wind' },
  { symbol: '🀄', type: 'Red Dragon' },
  { symbol: '🀅', type: 'Green Dragon' },
  { symbol: '🀆', type: 'White Dragon' },
  { symbol: '🀇', type: '1 Character' },
];

interface MahjongGameProps {
  onComplete?: (score: number) => void;
}

export const MahjongGame: React.FC<MahjongGameProps> = ({ onComplete }) => {
  const [tiles, setTiles] = useState<Tile[]>([]);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [score, setScore] = useState<number>(0);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  const initGame = () => {
    // Duplicate pairs to make 16 tiles total (8 pairs)
    const list: Tile[] = [];
    let idCounter = 1;
    TILE_PAIRS.forEach((item) => {
      list.push({ id: idCounter++, symbol: item.symbol, type: item.type, isMatched: false });
      list.push({ id: idCounter++, symbol: item.symbol, type: item.type, isMatched: false });
    });
    // Shuffle
    list.sort(() => Math.random() - 0.5);
    setTiles(list);
    setSelectedIdx(null);
    setScore(0);
    setIsCompleted(false);
  };

  useEffect(() => {
    initGame();
  }, []);

  const handleTileClick = (index: number) => {
    if (tiles[index].isMatched) return;

    if (selectedIdx === null) {
      setSelectedIdx(index);
    } else if (selectedIdx === index) {
      setSelectedIdx(null); // Deselect
    } else {
      // Check match
      const tileA = tiles[selectedIdx];
      const tileB = tiles[index];

      if (tileA.type === tileB.type) {
        const nextTiles = [...tiles];
        nextTiles[selectedIdx].isMatched = true;
        nextTiles[index].isMatched = true;
        setTiles(nextTiles);
        setSelectedIdx(null);

        const newScore = score + 120;
        setScore(newScore);

        if (nextTiles.every((t) => t.isMatched)) {
          setIsCompleted(true);
          if (onComplete) onComplete(newScore + 500);
        }
      } else {
        // Wrong match feedback
        setSelectedIdx(index);
      }
    }
  };

  const remainingCount = tiles.filter((t) => !t.isMatched).length;

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 uppercase tracking-wider">
            Game 3: Visual Solitaire
          </span>
          <h3 className="text-xl font-bold text-slate-800 mt-1 font-outfit">Mahjong Pair Solitaire</h3>
          <p className="text-xs text-slate-500">Select identical free Mahjong tiles to match and clear the board</p>
        </div>
        <button
          onClick={initGame}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Restart
        </button>
      </div>

      <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-100">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-emerald-600" />
          <span className="text-xs text-slate-500">Remaining Tiles:</span>
          <span className="text-sm font-bold text-slate-800 font-outfit">{remainingCount}</span>
        </div>
        <div>
          <span className="text-xs text-slate-500 mr-2">Score:</span>
          <span className="text-lg font-bold text-emerald-600 font-outfit">{score}</span>
        </div>
      </div>

      {isCompleted ? (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center space-y-3">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
            <Award className="w-6 h-6" />
          </div>
          <h4 className="text-lg font-bold text-emerald-900 font-outfit">Mahjong Solitaire Cleared!</h4>
          <p className="text-xs text-emerald-700">Wonderful concentration and visual perception! Total Score: {score + 500}</p>
          <button
            onClick={initGame}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium text-xs shadow-md transition-colors"
          >
            Play New Hand
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-4 gap-3 max-w-md mx-auto">
          {tiles.map((tile, idx) => (
            <button
              key={tile.id}
              onClick={() => handleTileClick(idx)}
              disabled={tile.isMatched}
              className={`h-24 rounded-2xl flex flex-col items-center justify-center border transition-all duration-200 relative ${
                tile.isMatched
                  ? 'opacity-0 pointer-events-none'
                  : selectedIdx === idx
                  ? 'bg-emerald-100 border-2 border-emerald-500 scale-105 shadow-lg'
                  : 'bg-gradient-to-b from-amber-50 to-amber-100 border-amber-200 text-slate-800 hover:border-emerald-400 shadow-sm cursor-pointer'
              }`}
            >
              <span className="text-4xl">{tile.symbol}</span>
              <span className="text-[10px] font-semibold text-slate-600 mt-1">{tile.type}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
