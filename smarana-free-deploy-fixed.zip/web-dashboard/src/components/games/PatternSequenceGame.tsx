import React, { useState, useEffect } from 'react';
import { RotateCcw, Award, Play, Activity } from 'lucide-react';

interface ColorPad {
  id: number;
  color: string;
  activeBg: string;
  idleBg: string;
  name: string;
}

const PADS: ColorPad[] = [
  { id: 0, color: 'emerald', idleBg: 'bg-emerald-500/30 border-emerald-400', activeBg: 'bg-emerald-400 scale-105 shadow-lg shadow-emerald-400/50', name: 'Green' },
  { id: 1, color: 'sky', idleBg: 'bg-sky-500/30 border-sky-400', activeBg: 'bg-sky-400 scale-105 shadow-lg shadow-sky-400/50', name: 'Blue' },
  { id: 2, color: 'amber', idleBg: 'bg-amber-500/30 border-amber-400', activeBg: 'bg-amber-400 scale-105 shadow-lg shadow-amber-400/50', name: 'Yellow' },
  { id: 3, color: 'rose', idleBg: 'bg-rose-500/30 border-rose-400', activeBg: 'bg-rose-400 scale-105 shadow-lg shadow-rose-400/50', name: 'Red' },
];

interface PatternSequenceGameProps {
  onComplete?: (score: number) => void;
}

export const PatternSequenceGame: React.FC<PatternSequenceGameProps> = ({ onComplete }) => {
  const [sequence, setSequence] = useState<number[]>([]);
  const [userStep, setUserStep] = useState<number>(0);
  const [activePad, setActivePad] = useState<number | null>(null);
  const [isPlayingSeq, setIsPlayingSeq] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [gameStarted, setGameStarted] = useState<boolean>(false);

  const startGame = () => {
    const firstPad = Math.floor(Math.random() * 4);
    setSequence([firstPad]);
    setUserStep(0);
    setScore(0);
    setGameOver(false);
    setGameStarted(true);
    playSequence([firstPad]);
  };

  const playSequence = (seq: number[]) => {
    setIsPlayingSeq(true);
    setUserStep(0);

    seq.forEach((padIdx, i) => {
      setTimeout(() => {
        setActivePad(padIdx);
        setTimeout(() => {
          setActivePad(null);
          if (i === seq.length - 1) {
            setIsPlayingSeq(false);
          }
        }, 600);
      }, (i + 1) * 900);
    });
  };

  const handlePadClick = (padIdx: number) => {
    if (isPlayingSeq || gameOver || !gameStarted) return;

    setActivePad(padIdx);
    setTimeout(() => setActivePad(null), 300);

    if (sequence[userStep] === padIdx) {
      const nextStep = userStep + 1;
      setUserStep(nextStep);

      if (nextStep === sequence.length) {
        // Round completed successfully
        const newScore = score + 150;
        setScore(newScore);

        setTimeout(() => {
          const nextPad = Math.floor(Math.random() * 4);
          const newSeq = [...sequence, nextPad];
          setSequence(newSeq);
          playSequence(newSeq);
        }, 1000);
      }
    } else {
      // Failed sequence
      setGameOver(true);
      if (onComplete) onComplete(score);
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <span className="text-xs font-semibold text-sky-600 bg-sky-50 px-2.5 py-1 rounded-full border border-sky-200 uppercase tracking-wider">
            Game 5: Pattern Memory
          </span>
          <h3 className="text-xl font-bold text-slate-800 mt-1 font-outfit">Color Pattern Sequence</h3>
          <p className="text-xs text-slate-500">Watch the light pattern sequence and repeat the exact order</p>
        </div>
        <button
          onClick={startGame}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Restart
        </button>
      </div>

      <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-100">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-sky-600" />
          <span className="text-xs text-slate-500">Sequence Level:</span>
          <span className="text-sm font-bold text-slate-800 font-outfit">{sequence.length}</span>
        </div>
        <div>
          <span className="text-xs text-slate-500 mr-2">Score:</span>
          <span className="text-lg font-bold text-sky-600 font-outfit">{score}</span>
        </div>
      </div>

      {!gameStarted ? (
        <div className="text-center p-8 space-y-4 bg-slate-50 rounded-2xl border border-slate-200">
          <p className="text-xs text-slate-600">Press Start to watch the color sequence lights!</p>
          <button
            onClick={startGame}
            className="px-6 py-3 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-bold text-sm shadow-md flex items-center gap-2 mx-auto transition-transform active:scale-95 cursor-pointer"
          >
            <Play className="w-4 h-4" /> Start Pattern Recall
          </button>
        </div>
      ) : gameOver ? (
        <div className="bg-sky-50 border border-sky-200 rounded-2xl p-6 text-center space-y-3">
          <div className="w-12 h-12 bg-sky-100 text-sky-600 rounded-full flex items-center justify-center mx-auto">
            <Award className="w-6 h-6" />
          </div>
          <h4 className="text-lg font-bold text-sky-900 font-outfit">Pattern Challenge Finished</h4>
          <p className="text-xs text-sky-700">You reached a sequence memory length of <span className="font-bold">{sequence.length} items</span>! Score: {score}</p>
          <button
            onClick={startGame}
            className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-medium text-xs shadow-md transition-colors"
          >
            Try Again
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          <p className="text-center text-xs font-semibold text-slate-500">
            {isPlayingSeq ? '👀 Pay Attention to the Sequence...' : '👉 Your Turn: Repeat the Pattern!'}
          </p>
          <div className="grid grid-cols-2 gap-4 w-64 h-64 mx-auto">
            {PADS.map((pad) => (
              <button
                key={pad.id}
                onClick={() => handlePadClick(pad.id)}
                disabled={isPlayingSeq}
                className={`rounded-2xl border-2 transition-all duration-200 flex items-center justify-center font-bold text-xs ${
                  activePad === pad.id ? pad.activeBg : pad.idleBg
                }`}
              >
                {pad.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
