import React, { useState, useEffect } from 'react';
import { RotateCcw, Award, Grid, Move, Sparkles } from 'lucide-react';

interface TilePuzzleGameProps {
  onComplete?: (score: number) => void;
}

const SOLVED_BOARD = [1, 2, 3, 4, 5, 6, 7, 8, 0];

export const TilePuzzleGame: React.FC<TilePuzzleGameProps> = ({ onComplete }) => {
  const [tiles, setTiles] = useState<number[]>([...SOLVED_BOARD]);
  const [moves, setMoves] = useState<number>(0);
  const [isSolved, setIsSolved] = useState<boolean>(false);

  const shuffleBoard = () => {
    let board = [...SOLVED_BOARD];
    // Perform random valid moves to ensure solvability
    for (let i = 0; i < 30; i++) {
      const emptyIdx = board.indexOf(0);
      const validMoves: number[] = [];
      const row = Math.floor(emptyIdx / 3);
      const col = emptyIdx % 3;

      if (row > 0) validMoves.push(emptyIdx - 3); // Up
      if (row < 2) validMoves.push(emptyIdx + 3); // Down
      if (col > 0) validMoves.push(emptyIdx - 1); // Left
      if (col < 2) validMoves.push(emptyIdx + 1); // Right

      const randomMove = validMoves[Math.floor(Math.random() * validMoves.length)];
      [board[emptyIdx], board[randomMove]] = [board[randomMove], board[emptyIdx]];
    }

    setTiles(board);
    setMoves(0);
    setIsSolved(false);
  };

  useEffect(() => {
    shuffleBoard();
  }, []);

  const handleTileClick = (index: number) => {
    if (isSolved || tiles[index] === 0) return;

    const emptyIdx = tiles.indexOf(0);
    const row = Math.floor(index / 3);
    const col = index % 3;
    const emptyRow = Math.floor(emptyIdx / 3);
    const emptyCol = emptyIdx % 3;

    // Check adjacency
    const isAdjacent =
      (Math.abs(row - emptyRow) === 1 && col === emptyCol) ||
      (Math.abs(col - emptyCol) === 1 && row === emptyRow);

    if (isAdjacent) {
      const newTiles = [...tiles];
      [newTiles[index], newTiles[emptyIdx]] = [newTiles[emptyIdx], newTiles[index]];
      setTiles(newTiles);
      const newMoves = moves + 1;
      setMoves(newMoves);

      // Check if solved
      if (newTiles.every((val, idx) => val === SOLVED_BOARD[idx])) {
        setIsSolved(true);
        if (onComplete) onComplete(Math.max(200, 1000 - newMoves * 15));
      }
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <span className="text-xs font-semibold text-purple-600 bg-purple-50 px-2.5 py-1 rounded-full border border-purple-200 uppercase tracking-wider">
            Game 2: Spatial Puzzle
          </span>
          <h3 className="text-xl font-bold text-slate-800 mt-1 font-outfit">3x3 Sliding Tile Puzzle</h3>
          <p className="text-xs text-slate-500">Arrange numbers 1 through 8 in order by sliding tiles into the empty space</p>
        </div>
        <button
          onClick={shuffleBoard}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Shuffle
        </button>
      </div>

      <div className="flex items-center justify-center gap-6">
        <div className="bg-slate-50 px-4 py-2 rounded-xl border border-slate-100 flex items-center gap-2">
          <Move className="w-4 h-4 text-purple-500" />
          <span className="text-xs text-slate-500">Total Moves:</span>
          <span className="text-base font-bold text-slate-800 font-outfit">{moves}</span>
        </div>
      </div>

      {isSolved ? (
        <div className="bg-purple-50 border border-purple-200 rounded-2xl p-6 text-center space-y-3">
          <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mx-auto">
            <Award className="w-6 h-6" />
          </div>
          <h4 className="text-lg font-bold text-purple-900 font-outfit">Puzzle Solved!</h4>
          <p className="text-xs text-purple-700">Great spatial reasoning! Completed in {moves} moves.</p>
          <button
            onClick={shuffleBoard}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-medium text-xs shadow-md transition-colors"
          >
            Play Next Puzzle
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-2 w-64 h-64 mx-auto p-3 bg-slate-800 rounded-2xl border-2 border-slate-700 shadow-inner">
          {tiles.map((val, idx) => (
            <button
              key={idx}
              onClick={() => handleTileClick(idx)}
              disabled={val === 0}
              className={`rounded-xl text-xl font-bold font-outfit flex items-center justify-center transition-all duration-200 ${
                val === 0
                  ? 'bg-slate-900/50 cursor-default border border-dashed border-slate-700'
                  : 'bg-gradient-to-br from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 border border-amber-300 shadow-md cursor-pointer active:scale-95'
              }`}
            >
              {val !== 0 && val}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
