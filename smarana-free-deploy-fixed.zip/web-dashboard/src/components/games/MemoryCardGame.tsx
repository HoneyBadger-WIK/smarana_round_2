import React, { useState, useEffect } from 'react';
import { RotateCcw, Award, CheckCircle, Brain, Sparkles, Clock } from 'lucide-react';

interface Card {
  id: number;
  symbol: string;
  isFlipped: boolean;
  isMatched: boolean;
}

const CARD_SYMBOLS = ['🌸', '🦏', '🫖', '🎋', '🦚', '⛰️'];

interface MemoryCardGameProps {
  onComplete?: (score: number, durationSec: number) => void;
}

export const MemoryCardGame: React.FC<MemoryCardGameProps> = ({ onComplete }) => {
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [moves, setMoves] = useState<number>(0);
  const [matches, setMatches] = useState<number>(0);
  const [seconds, setSeconds] = useState<number>(0);
  const [gameEnded, setGameEnded] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  const initGame = () => {
    const deck = [...CARD_SYMBOLS, ...CARD_SYMBOLS]
      .sort(() => Math.random() - 0.5)
      .map((symbol, index) => ({
        id: index,
        symbol,
        isFlipped: false,
        isMatched: false,
      }));
    setCards(deck);
    setFlippedIndices([]);
    setMoves(0);
    setMatches(0);
    setSeconds(0);
    setGameEnded(false);
    setIsProcessing(false);
  };

  useEffect(() => {
    initGame();
  }, []);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (!gameEnded) {
      timer = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [gameEnded]);

  const handleCardClick = (index: number) => {
    if (
      isProcessing ||
      cards[index].isFlipped ||
      cards[index].isMatched ||
      flippedIndices.length === 2
    ) {
      return;
    }

    const newCards = [...cards];
    newCards[index].isFlipped = true;
    setCards(newCards);

    const newFlipped = [...flippedIndices, index];
    setFlippedIndices(newFlipped);

    if (newFlipped.length === 2) {
      setMoves((prev) => prev + 1);
      setIsProcessing(true);

      const [firstIdx, secondIdx] = newFlipped;
      if (cards[firstIdx].symbol === cards[secondIdx].symbol) {
        setTimeout(() => {
          setCards((prev) =>
            prev.map((c, i) =>
              i === firstIdx || i === secondIdx ? { ...c, isMatched: true } : c
            )
          );
          setFlippedIndices([]);
          setMatches((prev) => {
            const nextMatches = prev + 1;
            if (nextMatches === CARD_SYMBOLS.length) {
              setGameEnded(true);
              const finalScore = Math.max(100, 1000 - moves * 20 - seconds * 5);
              if (onComplete) onComplete(finalScore, seconds);
            }
            return nextMatches;
          });
          setIsProcessing(false);
        }, 500);
      } else {
        setTimeout(() => {
          setCards((prev) =>
            prev.map((c, i) =>
              i === firstIdx || i === secondIdx ? { ...c, isFlipped: false } : c
            )
          );
          setFlippedIndices([]);
          setIsProcessing(false);
        }, 1000);
      }
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <span className="text-xs font-semibold text-teal-600 bg-teal-50 px-2.5 py-1 rounded-full border border-teal-200 uppercase tracking-wider">
            Game 1: Memory Focus
          </span>
          <h3 className="text-xl font-bold text-slate-800 mt-1 font-outfit">Memory Card Match</h3>
          <p className="text-xs text-slate-500">Flip cards and match identical symbols to sharpen recall</p>
        </div>
        <button
          onClick={initGame}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset Game
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4 text-center">
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
          <p className="text-xs text-slate-400 font-medium">Moves</p>
          <p className="text-lg font-bold text-slate-700 font-outfit">{moves}</p>
        </div>
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
          <p className="text-xs text-slate-400 font-medium">Matches</p>
          <p className="text-lg font-bold text-teal-600 font-outfit">{matches} / {CARD_SYMBOLS.length}</p>
        </div>
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
          <p className="text-xs text-slate-400 font-medium">Time Elapsed</p>
          <p className="text-lg font-bold text-slate-700 font-outfit flex items-center justify-center gap-1">
            <Clock className="w-4 h-4 text-slate-400" />
            {seconds}s
          </p>
        </div>
      </div>

      {gameEnded ? (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center space-y-3 animate-fade-in">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
            <Award className="w-6 h-6" />
          </div>
          <h4 className="text-lg font-bold text-emerald-900 font-outfit">Excellent Memory Recall!</h4>
          <p className="text-xs text-emerald-700">
            You completed the game in <span className="font-bold">{moves} moves</span> and <span className="font-bold">{seconds} seconds</span>!
          </p>
          <button
            onClick={initGame}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-medium text-xs shadow-md transition-colors"
          >
            Play Again
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-4 gap-3 max-w-md mx-auto">
          {cards.map((card, index) => (
            <button
              key={index}
              onClick={() => handleCardClick(index)}
              disabled={card.isMatched || card.isFlipped}
              className={`h-24 rounded-xl text-3xl flex items-center justify-center transition-all duration-300 transform shadow-sm ${
                card.isFlipped || card.isMatched
                  ? 'bg-teal-50 border-2 border-teal-500 scale-105'
                  : 'bg-gradient-to-br from-slate-700 to-slate-800 hover:from-slate-600 hover:to-slate-700 border border-slate-600 cursor-pointer'
              }`}
            >
              {card.isFlipped || card.isMatched ? card.symbol : '❓'}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
