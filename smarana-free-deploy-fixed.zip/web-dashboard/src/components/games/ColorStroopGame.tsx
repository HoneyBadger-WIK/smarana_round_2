import React, { useState, useEffect } from 'react';
import { RotateCcw, Award, Zap, Check, X } from 'lucide-react';

interface StroopTrial {
  text: string;
  colorName: string;
  colorHex: string;
}

const COLOR_ITEMS = [
  { name: 'RED', hex: '#ef4444' },
  { name: 'BLUE', hex: '#3b82f6' },
  { name: 'GREEN', hex: '#10b981' },
  { name: 'YELLOW', hex: '#eab308' },
  { name: 'PURPLE', hex: '#a855f7' },
];

interface ColorStroopGameProps {
  onComplete?: (score: number) => void;
}

export const ColorStroopGame: React.FC<ColorStroopGameProps> = ({ onComplete }) => {
  const [trial, setTrial] = useState<StroopTrial>({ text: 'RED', colorName: 'BLUE', colorHex: '#3b82f6' });
  const [score, setScore] = useState<number>(0);
  const [roundsLeft, setRoundsLeft] = useState<number>(10);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);

  const generateTrial = () => {
    const textObj = COLOR_ITEMS[Math.floor(Math.random() * COLOR_ITEMS.length)];
    let colorObj = COLOR_ITEMS[Math.floor(Math.random() * COLOR_ITEMS.length)];
    // Encourage mismatch to create Stroop effect
    while (colorObj.name === textObj.name && Math.random() > 0.3) {
      colorObj = COLOR_ITEMS[Math.floor(Math.random() * COLOR_ITEMS.length)];
    }
    setTrial({ text: textObj.name, colorName: colorObj.name, colorHex: colorObj.hex });
    setFeedback(null);
  };

  useEffect(() => {
    generateTrial();
  }, []);

  const handleChoice = (colorName: string) => {
    if (isGameOver || feedback !== null) return;

    if (colorName === trial.colorName) {
      setScore((prev) => prev + 100);
      setFeedback('correct');
    } else {
      setFeedback('wrong');
    }

    setTimeout(() => {
      if (roundsLeft > 1) {
        setRoundsLeft((prev) => prev - 1);
        generateTrial();
      } else {
        setIsGameOver(true);
        if (onComplete) onComplete(score + (colorName === trial.colorName ? 100 : 0));
      }
    }, 500);
  };

  const restart = () => {
    setScore(0);
    setRoundsLeft(10);
    setIsGameOver(false);
    generateTrial();
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <span className="text-xs font-semibold text-rose-600 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200 uppercase tracking-wider">
            Game 6: Cognitive Control
          </span>
          <h3 className="text-xl font-bold text-slate-800 mt-1 font-outfit">Color Stroop Challenge</h3>
          <p className="text-xs text-slate-500">
            Click the <span className="font-bold underline">COLOR of the ink</span>, ignoring what the text word says!
          </p>
        </div>
        <button
          onClick={restart}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Restart
        </button>
      </div>

      <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-100">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-rose-500" />
          <span className="text-xs text-slate-500">Rounds Remaining:</span>
          <span className="text-sm font-bold text-slate-800 font-outfit">{roundsLeft}</span>
        </div>
        <div>
          <span className="text-xs text-slate-500 mr-2">Score:</span>
          <span className="text-lg font-bold text-rose-600 font-outfit">{score}</span>
        </div>
      </div>

      {!isGameOver ? (
        <div className="space-y-6">
          <div className="h-36 bg-slate-900 rounded-2xl border border-slate-800 flex items-center justify-center relative shadow-inner">
            <span
              className="text-5xl font-black font-outfit tracking-widest transition-all scale-110"
              style={{ color: trial.colorHex }}
            >
              {trial.text}
            </span>

            {feedback && (
              <div
                className={`absolute inset-0 rounded-2xl flex items-center justify-center backdrop-blur-xs transition-opacity ${
                  feedback === 'correct' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                }`}
              >
                {feedback === 'correct' ? <Check className="w-12 h-12" /> : <X className="w-12 h-12" />}
              </div>
            )}
          </div>

          <div className="grid grid-cols-5 gap-2">
            {COLOR_ITEMS.map((item) => (
              <button
                key={item.name}
                onClick={() => handleChoice(item.name)}
                disabled={feedback !== null}
                className="py-3 px-2 rounded-xl text-xs font-bold font-outfit border bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-800 transition-all cursor-pointer hover:scale-105 active:scale-95 text-center shadow-xs"
              >
                {item.name}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-6 text-center space-y-3">
          <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto">
            <Award className="w-6 h-6" />
          </div>
          <h4 className="text-lg font-bold text-rose-900 font-outfit">Stroop Test Complete!</h4>
          <p className="text-xs text-rose-700">Excellent inhibitory control and response agility! Final Score: {score}</p>
          <button
            onClick={restart}
            className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-medium text-xs shadow-md transition-colors"
          >
            Play Again
          </button>
        </div>
      )}
    </div>
  );
};
