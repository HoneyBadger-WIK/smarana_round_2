import React, { useState } from 'react';
import { RotateCcw, Award, BookOpen, Check, X, Sparkles } from 'lucide-react';

interface Question {
  prompt: string;
  category: string;
  correctWord: string;
  options: string[];
  explanation: string;
}

const QUESTIONS: Question[] = [
  {
    prompt: 'Assam Tea',
    category: 'Cultural & Daily Memories',
    correctWord: 'Leaves',
    options: ['Leaves', 'Keyboard', 'Submarine', 'Plastic'],
    explanation: 'Tea is cultivated from fresh green tea leaves grown in lush Assam gardens.',
  },
  {
    prompt: 'Bihu Festival',
    category: 'Regional Traditions',
    correctWord: 'Dance',
    options: ['Snowstorm', 'Dance', 'Astronaut', 'Engine'],
    explanation: 'Bihu is celebrated with energetic folk music and traditional Bihu dance.',
  },
  {
    prompt: 'Brahmaputra River',
    category: 'Geography & Nature',
    correctWord: 'Watercraft',
    options: ['Volcano', 'Desert', 'Watercraft', 'Skyscraper'],
    explanation: 'Ferries and boats navigate the majestic Brahmaputra River.',
  },
  {
    prompt: 'Morning Garden',
    category: 'Nature & Wellness',
    correctWord: 'Flowers',
    options: ['Concrete', 'Flowers', 'Telephone', 'Circuit'],
    explanation: 'Gardens bloom with vibrant, fragrant flowers in the early morning sunlight.',
  },
];

interface WordAssociationGameProps {
  onComplete?: (score: number) => void;
}

export const WordAssociationGame: React.FC<WordAssociationGameProps> = ({ onComplete }) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [score, setScore] = useState<number>(0);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const currentQ = QUESTIONS[currentIdx];

  const handleSelect = (opt: string) => {
    if (isAnswered) return;
    setSelectedOption(opt);
    setIsAnswered(true);

    if (opt === currentQ.correctWord) {
      setScore((prev) => prev + 250);
    }
  };

  const handleNext = () => {
    if (currentIdx + 1 < QUESTIONS.length) {
      setCurrentIdx((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setIsFinished(true);
      if (onComplete) onComplete(score);
    }
  };

  const restart = () => {
    setCurrentIdx(0);
    setSelectedOption(null);
    setScore(0);
    setIsAnswered(false);
    setIsFinished(false);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <span className="text-xs font-semibold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200 uppercase tracking-wider">
            Game 4: Language & Memory
          </span>
          <h3 className="text-xl font-bold text-slate-800 mt-1 font-outfit">Word Association & Recall</h3>
          <p className="text-xs text-slate-500">Connect meaningful concepts and recall semantic relationships</p>
        </div>
        <button
          onClick={restart}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Restart
        </button>
      </div>

      {!isFinished ? (
        <div className="space-y-6">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Question {currentIdx + 1} of {QUESTIONS.length}</span>
            <span className="font-semibold text-amber-600">Category: {currentQ.category}</span>
          </div>

          <div className="bg-amber-50/60 border border-amber-200/80 rounded-2xl p-6 text-center space-y-2">
            <span className="text-xs text-amber-700 font-medium uppercase tracking-widest">Select the strongest match for:</span>
            <h4 className="text-3xl font-extrabold text-amber-950 font-outfit">{currentQ.prompt}</h4>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {currentQ.options.map((opt) => {
              const isSelected = selectedOption === opt;
              const isCorrect = opt === currentQ.correctWord;

              let btnClass = 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-amber-50 hover:border-amber-300';
              if (isAnswered) {
                if (isCorrect) {
                  btnClass = 'bg-emerald-100 border-emerald-500 text-emerald-900 font-bold';
                } else if (isSelected) {
                  btnClass = 'bg-rose-100 border-rose-400 text-rose-900 font-bold';
                }
              }

              return (
                <button
                  key={opt}
                  onClick={() => handleSelect(opt)}
                  disabled={isAnswered}
                  className={`p-4 rounded-xl border text-base transition-all flex items-center justify-between font-medium cursor-pointer ${btnClass}`}
                >
                  <span>{opt}</span>
                  {isAnswered && isCorrect && <Check className="w-5 h-5 text-emerald-600" />}
                  {isAnswered && isSelected && !isCorrect && <X className="w-5 h-5 text-rose-600" />}
                </button>
              );
            })}
          </div>

          {isAnswered && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
              <p className="text-xs text-slate-600"><span className="font-semibold">Context Note:</span> {currentQ.explanation}</p>
              <button
                onClick={handleNext}
                className="w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-medium text-xs shadow-md transition-colors"
              >
                {currentIdx + 1 < QUESTIONS.length ? 'Next Word Challenge' : 'Complete Game'}
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 text-center space-y-3">
          <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto">
            <Award className="w-6 h-6" />
          </div>
          <h4 className="text-lg font-bold text-amber-900 font-outfit">Word Association Complete!</h4>
          <p className="text-xs text-amber-700">Excellent semantic association! Final Score: <span className="font-bold">{score} pts</span></p>
          <button
            onClick={restart}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-medium text-xs shadow-md transition-colors"
          >
            Play Again
          </button>
        </div>
      )}
    </div>
  );
};
