import React from 'react';
import { CognitiveTrend } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, LineChart, Line, Legend } from 'recharts';
import { TrendingUp, Award, Zap } from 'lucide-react';

interface CognitiveChartsProps {
  trends: CognitiveTrend[];
}

export const CognitiveCharts: React.FC<CognitiveChartsProps> = ({ trends }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Engagement Trend Chart */}
      <div className="glass-panel p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-teal-400" />
              Cognitive Engagement Trend
            </h3>
            <p className="text-xs text-slate-400">Weekly non-diagnostic wellness engagement score</p>
          </div>
          <span className="px-2.5 py-1 rounded-full text-xs bg-teal-500/10 text-teal-300 font-semibold border border-teal-500/20">
            +14% vs Last Week
          </span>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorEngagement" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0d9488" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#0d9488" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="date" stroke="#64748b" tick={{ fontSize: 12 }} />
              <YAxis stroke="#64748b" domain={[50, 100]} tick={{ fontSize: 12 }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', color: '#f8fafc' }}
                itemStyle={{ color: '#2dd4bf' }}
              />
              <Area type="monotone" dataKey="engagementScore" name="Engagement Score" stroke="#0d9488" strokeWidth={3} fillOpacity={1} fill="url(#colorEngagement)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Game Breakdown Chart */}
      <div className="glass-panel p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-400" />
              Game Category Performance
            </h3>
            <p className="text-xs text-slate-400">Memory Matrix vs Pattern Recall vs Word Association</p>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="w-2.5 h-2.5 rounded-full bg-teal-400"></span>
            <span className="text-slate-400">Memory</span>
            <span className="w-2.5 h-2.5 rounded-full bg-purple-400 ml-2"></span>
            <span className="text-slate-400">Pattern</span>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="date" stroke="#64748b" tick={{ fontSize: 12 }} />
              <YAxis stroke="#64748b" domain={[0, 100]} tick={{ fontSize: 12 }} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }} 
              />
              <Bar dataKey="memoryMatrixScore" name="Memory Matrix" fill="#0d9488" radius={[4, 4, 0, 0]} />
              <Bar dataKey="patternRecallScore" name="Pattern Recall" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="wordAssocScore" name="Word Association" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Dynamic Difficulty Level Adjustments */}
      <div className="glass-panel p-5 col-span-1 lg:col-span-2 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              Adaptive Difficulty Engine (DDA) Progression
            </h3>
            <p className="text-xs text-slate-400">RandomForest model difficulty level adjustment based on reaction speed & accuracy</p>
          </div>
          <span className="px-3 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-300 font-mono text-xs rounded-lg font-semibold">
            Current Level: 4 (Advanced Engagement)
          </span>
        </div>

        <div className="h-52 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trends} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="date" stroke="#64748b" tick={{ fontSize: 12 }} />
              <YAxis stroke="#64748b" domain={[1, 5]} ticks={[1, 2, 3, 4, 5]} tick={{ fontSize: 12 }} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }} />
              <Line type="stepAfter" dataKey="ddaDifficultyLevel" name="DDA Difficulty Level" stroke="#f59e0b" strokeWidth={3} dot={{ r: 5, fill: '#f59e0b' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
