import React from 'react';
import { GameSession } from '../types';
import { History, Zap, Timer, CheckCircle } from 'lucide-react';

interface GameSessionHistoryProps {
  sessions: GameSession[];
}

export const GameSessionHistory: React.FC<GameSessionHistoryProps> = ({ sessions }) => {
  return (
    <div className="glass-panel p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <History className="w-5 h-5 text-teal-400" />
            Recent Session History
          </h3>
          <p className="text-xs text-slate-400">Detailed metrics from completed cognitive wellness games</p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-900/80 text-slate-400 font-semibold border-b border-slate-800">
            <tr>
              <th className="py-2.5 px-3">Game Type</th>
              <th className="py-2.5 px-3">Score</th>
              <th className="py-2.5 px-3">Accuracy</th>
              <th className="py-2.5 px-3">Reaction Time</th>
              <th className="py-2.5 px-3">DDA Level</th>
              <th className="py-2.5 px-3">Date/Time</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {sessions.map((session) => (
              <tr key={session.id} className="hover:bg-slate-900/40 transition-colors">
                <td className="py-3 px-3 font-semibold text-white capitalize">
                  {session.game_type.replace('_', ' ')}
                </td>
                <td className="py-3 px-3 text-teal-400 font-mono font-bold">
                  {session.score} pts
                </td>
                <td className="py-3 px-3">
                  <span className="flex items-center gap-1 text-emerald-400">
                    <CheckCircle className="w-3.5 h-3.5" />
                    {(session.accuracy * 100).toFixed(0)}%
                  </span>
                </td>
                <td className="py-3 px-3 text-slate-400 font-mono">
                  <span className="flex items-center gap-1">
                    <Timer className="w-3.5 h-3.5 text-slate-500" />
                    {session.reaction_time_ms} ms
                  </span>
                </td>
                <td className="py-3 px-3">
                  <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20 font-bold font-mono">
                    L{session.dda_level_applied}
                  </span>
                </td>
                <td className="py-3 px-3 text-slate-400">
                  {new Date(session.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
