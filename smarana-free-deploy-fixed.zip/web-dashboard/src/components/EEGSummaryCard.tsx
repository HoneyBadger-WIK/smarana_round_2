import React from 'react';
import { Activity, ShieldAlert, Cpu, BarChart2 } from 'lucide-react';

export const EEGSummaryCard: React.FC = () => {
  const eegBands = [
    { name: 'Alpha Band (8-12 Hz)', value: '38.4 µV²', status: 'Optimal Engagement', color: 'text-emerald-400', barWidth: '78%' },
    { name: 'Beta Band (12-30 Hz)', value: '24.1 µV²', status: 'Active Focus', color: 'text-teal-400', barWidth: '65%' },
    { name: 'Theta Band (4-8 Hz)', value: '18.2 µV²', status: 'Relaxed / Resting', color: 'text-purple-400', barWidth: '45%' },
    { name: 'Delta Band (0.5-4 Hz)', value: '8.7 µV²', status: 'Baseline', color: 'text-slate-400', barWidth: '22%' },
  ];

  return (
    <div className="glass-panel p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-teal-400" />
            EEG Signal Power Spectral Summary (MCSAD Dataset Feature Matrix)
          </h3>
          <p className="text-xs text-slate-400">Non-diagnostic sensor signal power distribution during cognitive exercises</p>
        </div>

        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px] text-slate-300 font-mono">
          <BarChart2 className="w-3.5 h-3.5 text-teal-400" />
          <span>Sampling: 250 Hz</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {eegBands.map((band, idx) => (
          <div key={idx} className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200">{band.name}</span>
              <span className={`font-mono font-bold ${band.color}`}>{band.value}</span>
            </div>
            <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
              <div
                className="bg-gradient-to-r from-teal-500 to-emerald-400 h-2 rounded-full transition-all duration-500"
                style={{ width: band.barWidth }}
              ></div>
            </div>
            <div className="flex justify-between items-center text-[10px] text-slate-400">
              <span>Band Power Ratio</span>
              <span className="text-slate-300 font-medium">{band.status}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-400 flex items-start gap-2.5">
        <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong className="text-slate-200">Clinical Protocol Notice:</strong> Signal spectral metrics are extracted for tracking session engagement trends and fine-tuning the DDA machine learning model. They are non-diagnostic and should not be used as standalone clinical criteria.
        </p>
      </div>
    </div>
  );
};
