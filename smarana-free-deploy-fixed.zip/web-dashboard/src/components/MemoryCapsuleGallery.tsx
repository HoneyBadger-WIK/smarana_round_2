import React from 'react';
import { MemoryCapsule } from '../types';
import { Image as ImageIcon, Plus, Tag, Calendar, Sparkles } from 'lucide-react';

interface MemoryCapsuleGalleryProps {
  capsules: MemoryCapsule[];
  onUploadNew?: () => void;
}

export const MemoryCapsuleGallery: React.FC<MemoryCapsuleGalleryProps> = ({ capsules, onUploadNew }) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-400" />
            Reminiscence Memory Vault
          </h2>
          <p className="text-xs text-slate-400">Personalized memory anchors used in cognitive association exercises</p>
        </div>

        <button
          onClick={onUploadNew}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-medium text-xs shadow-lg shadow-teal-600/20 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Add Memory Capsule
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {capsules.map((capsule) => (
          <div key={capsule.id} className="glass-card p-4 flex flex-col justify-between group">
            <div className="space-y-3">
              <div className="h-36 rounded-lg bg-slate-800/80 border border-slate-700/60 overflow-hidden relative flex items-center justify-center group-hover:border-teal-500/50 transition-colors">
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60 z-10"></div>
                <ImageIcon className="w-10 h-10 text-slate-600 group-hover:text-teal-400 transition-colors" />
                <span className="absolute top-2 right-2 z-20 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-900/80 text-teal-300 border border-slate-700 uppercase">
                  {capsule.category}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-sm text-white group-hover:text-teal-300 transition-colors">{capsule.title}</h3>
                <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">{capsule.description}</p>
              </div>
            </div>

            <div className="pt-3 mt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {capsule.created_at}
              </span>
              <span className="flex items-center gap-1 text-teal-400 font-medium">
                <Tag className="w-3.5 h-3.5" />
                {capsule.tag_count || 4} Prompts
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
