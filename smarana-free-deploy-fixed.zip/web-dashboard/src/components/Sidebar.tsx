import React from 'react';
import { LayoutDashboard, HeartPulse, Image, CalendarCheck, Activity, Settings, HelpCircle } from 'lucide-react';

export type ActiveTab = 'overview' | 'caregiver' | 'clinical' | 'vault' | 'routines';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const navItems = [
    { id: 'overview', label: 'Overview Dashboard', icon: LayoutDashboard },
    { id: 'caregiver', label: 'Caregiver Telemetry', icon: HeartPulse },
    { id: 'clinical', label: 'Clinical Analytics', icon: Activity },
    { id: 'vault', label: 'Memory Vault', icon: Image },
    { id: 'routines', label: 'Daily Routines', icon: CalendarCheck },
  ];

  return (
    <aside className="w-64 border-r border-slate-800/80 bg-slate-950/50 p-4 flex flex-col justify-between hidden md:flex shrink-0">
      <div className="space-y-6">
        <div>
          <p className="px-3 text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">Navigation</p>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as ActiveTab)}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all ${
                    isActive
                      ? 'bg-teal-500/10 text-teal-300 border border-teal-500/20 font-semibold shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-teal-400' : 'text-slate-400'}`} />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="pt-4 border-t border-slate-800/60">
          <p className="px-3 text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">System Status</p>
          <div className="px-3 py-2.5 rounded-xl bg-slate-900/40 border border-slate-800/60 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Offline Engine</span>
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> Ready
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">DDA ML Model</span>
              <span className="text-teal-400 font-medium">RandomForest v1.2</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Sync Status</span>
              <span className="text-slate-300">Local DB Active</span>
            </div>
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-slate-800/60 space-y-1">
        <button className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 transition-colors">
          <Settings className="w-4 h-4 text-slate-500" />
          Platform Settings
        </button>
        <button className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 transition-colors">
          <HelpCircle className="w-4 h-4 text-slate-500" />
          Help & Support
        </button>
      </div>
    </aside>
  );
};
