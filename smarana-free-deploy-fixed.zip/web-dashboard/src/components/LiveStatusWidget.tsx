import React from 'react';
import { LivePatientStatus } from '../types';
import { Radio, Battery, Clock, Gamepad2, ShieldCheck, AlertTriangle } from 'lucide-react';

interface LiveStatusWidgetProps {
  status: LivePatientStatus | null;
}

export const LiveStatusWidget: React.FC<LiveStatusWidgetProps> = ({ status }) => {
  if (!status) {
    return (
      <div className="glass-card p-5 animate-pulse flex items-center justify-between">
        <div className="h-6 bg-slate-800 rounded w-1/3"></div>
        <div className="h-6 bg-slate-800 rounded w-1/4"></div>
      </div>
    );
  }

  const isSos = status.status === 'sos_triggered';
  const isPlaying = status.status === 'active_game';

  return (
    <div className={`glass-panel p-5 relative overflow-hidden transition-all border-l-4 ${
      isSos 
        ? 'border-l-red-500 bg-red-950/20' 
        : isPlaying 
          ? 'border-l-teal-500' 
          : 'border-l-slate-700'
    }`}>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
            isSos 
              ? 'bg-red-500/20 text-red-400 border border-red-500/30' 
              : isPlaying 
                ? 'bg-teal-500/20 text-teal-400 border border-teal-500/30' 
                : 'bg-slate-800 text-slate-400 border border-slate-700'
          }`}>
            {isSos ? (
              <AlertTriangle className="w-6 h-6 animate-bounce" />
            ) : isPlaying ? (
              <Gamepad2 className="w-6 h-6 animate-pulse" />
            ) : (
              <Radio className="w-6 h-6" />
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white">{status.patient_name}</h3>
              <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                isSos 
                  ? 'bg-red-500/20 text-red-300 border border-red-500/40' 
                  : isPlaying 
                    ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40' 
                    : 'bg-slate-800 text-slate-300'
              }`}>
                <span className={`w-2 h-2 rounded-full ${
                  isSos ? 'bg-red-500 animate-ping' : isPlaying ? 'bg-teal-400 animate-pulse' : 'bg-slate-500'
                }`}></span>
                {isSos ? 'SOS Alert' : isPlaying ? 'Playing Game' : 'Idle / Resting'}
              </span>
            </div>

            <p className="text-xs text-slate-400 mt-1 flex items-center gap-2">
              {isPlaying && status.current_game && (
                <span className="text-teal-300 font-medium">{status.current_game}</span>
              )}
              <span>•</span>
              <span>Sessions today: <strong className="text-white">{status.today_sessions_count}</strong></span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6 text-xs text-slate-400 self-end sm:self-center">
          <div className="flex items-center gap-1.5 bg-slate-900/60 px-3 py-1.5 rounded-lg border border-slate-800">
            <Battery className="w-4 h-4 text-emerald-400" />
            <span>{status.battery_level}% Battery</span>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-900/60 px-3 py-1.5 rounded-lg border border-slate-800">
            <Clock className="w-4 h-4 text-teal-400" />
            <span>{status.last_heartbeat}</span>
          </div>

          <div className="flex items-center gap-1 text-emerald-400 font-medium">
            <ShieldCheck className="w-4 h-4" />
            <span className="hidden lg:inline">Telemetry Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};
