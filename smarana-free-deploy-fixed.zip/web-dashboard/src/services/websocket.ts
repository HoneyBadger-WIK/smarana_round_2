import { LivePatientStatus } from '../types';

type StatusCallback = (status: LivePatientStatus) => void;

export class LiveStatusWebSocket {
  private socket: WebSocket | null = null;
  private listeners: StatusCallback[] = [];
  private isFallback: boolean = false;
  private intervalId: any = null;

  connect() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws/live`;

    try {
      this.socket = new WebSocket(wsUrl);

      this.socket.onopen = () => {
        console.log('[SMARANA WS] Connected to live status feed');
        this.isFallback = false;
      };

      this.socket.onmessage = (event) => {
        try {
          const data: LivePatientStatus = JSON.parse(event.data);
          this.notify(data);
        } catch (e) {
          console.error('[SMARANA WS] Parse error:', e);
        }
      };

      this.socket.onerror = () => {
        console.warn('[SMARANA WS] Connection error, initiating fallback simulation mode');
        this.startFallbackSimulation();
      };

      this.socket.onclose = () => {
        console.warn('[SMARANA WS] Connection closed');
        this.startFallbackSimulation();
      };
    } catch (e) {
      console.warn('[SMARANA WS] Exception initializing socket, using simulation fallback', e);
      this.startFallbackSimulation();
    }
  }

  subscribe(callback: StatusCallback) {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  private notify(data: LivePatientStatus) {
    this.listeners.forEach(l => l(data));
  }

  private startFallbackSimulation() {
    if (this.intervalId) return;
    this.isFallback = true;
    
    // Initial emission
    this.notify({
      patient_id: 'p-1029',
      patient_name: 'Anandi Sharma',
      status: 'active_game',
      current_game: 'Memory Matrix (Level 4)',
      battery_level: 88,
      last_heartbeat: new Date().toLocaleTimeString(),
      today_sessions_count: 3
    });

    this.intervalId = setInterval(() => {
      const statuses: ('active_game' | 'idle' | 'resting')[] = ['active_game', 'idle', 'resting'];
      const games = ['Memory Matrix (Level 4)', 'Pattern Recall (Level 3)', 'Word Association (Level 3)'];
      const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
      
      this.notify({
        patient_id: 'p-1029',
        patient_name: 'Anandi Sharma',
        status: randomStatus,
        current_game: randomStatus === 'active_game' ? games[Math.floor(Math.random() * games.length)] : undefined,
        battery_level: Math.max(70, Math.floor(88 - Math.random() * 5)),
        last_heartbeat: new Date().toLocaleTimeString(),
        today_sessions_count: 3
      });
    }, 5000);
  }

  disconnect() {
    if (this.socket) {
      this.socket.close();
    }
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }
}

export const liveSocket = new LiveStatusWebSocket();
