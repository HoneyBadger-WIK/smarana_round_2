import { CognitiveTrend, GameSession, MemoryCapsule, PatientInfo, RoutineTask, User } from '../types';

const API_BASE_URL = '/api/v1';

export const apiService = {
  async fetchPatients(): Promise<PatientInfo[]> {
    return [
      {
        id: 'p-101',
        name: 'Anandi Sharma',
        age: 72,
        location: 'Guwahati, Assam',
        status: 'active_game',
        current_game: 'Mahjong Solitaire (L3)',
        battery_level: 88,
        last_active: '2 mins ago',
        routines_completed: 3,
        total_routines: 5,
        dda_level: 4,
        risk_status: 'optimal',
      },
      {
        id: 'p-102',
        name: 'Ramesh Verma',
        age: 78,
        location: 'Tezpur, Assam',
        status: 'idle',
        battery_level: 94,
        last_active: '15 mins ago',
        routines_completed: 4,
        total_routines: 5,
        dda_level: 3,
        risk_status: 'stable',
      },
      {
        id: 'p-103',
        name: 'Kamala Devi',
        age: 69,
        location: 'Shillong, Meghalaya',
        status: 'active_game',
        current_game: 'Memory Card Match (L2)',
        battery_level: 76,
        last_active: 'Just now',
        routines_completed: 2,
        total_routines: 4,
        dda_level: 2,
        risk_status: 'stable',
      },
      {
        id: 'p-104',
        name: 'Bishnu Prasad Kalita',
        age: 81,
        location: 'Jorhat, Assam',
        status: 'resting',
        battery_level: 82,
        last_active: '1 hour ago',
        routines_completed: 1,
        total_routines: 4,
        dda_level: 3,
        risk_status: 'attention_needed',
      },
    ];
  },

  async fetchCognitiveTrends(): Promise<CognitiveTrend[]> {
    return [
      { date: 'Mon', engagementScore: 78, memoryMatrixScore: 82, patternRecallScore: 70, wordAssocScore: 85, ddaDifficultyLevel: 2 },
      { date: 'Tue', engagementScore: 82, memoryMatrixScore: 85, patternRecallScore: 75, wordAssocScore: 88, ddaDifficultyLevel: 2 },
      { date: 'Wed', engagementScore: 79, memoryMatrixScore: 80, patternRecallScore: 78, wordAssocScore: 82, ddaDifficultyLevel: 3 },
      { date: 'Thu', engagementScore: 88, memoryMatrixScore: 91, patternRecallScore: 84, wordAssocScore: 90, ddaDifficultyLevel: 3 },
      { date: 'Fri', engagementScore: 85, memoryMatrixScore: 87, patternRecallScore: 81, wordAssocScore: 89, ddaDifficultyLevel: 3 },
      { date: 'Sat', engagementScore: 91, memoryMatrixScore: 94, patternRecallScore: 88, wordAssocScore: 92, ddaDifficultyLevel: 4 },
      { date: 'Sun', engagementScore: 94, memoryMatrixScore: 96, patternRecallScore: 90, wordAssocScore: 95, ddaDifficultyLevel: 4 },
    ];
  },

  async fetchGameSessions(): Promise<GameSession[]> {
    return [
      { id: '1', game_type: 'memory_card', score: 920, reaction_time_ms: 1240, accuracy: 0.94, dda_level_applied: 4, created_at: '2026-09-01T14:30:00Z' },
      { id: '2', game_type: 'mahjong', score: 880, reaction_time_ms: 1350, accuracy: 0.91, dda_level_applied: 3, created_at: '2026-09-01T12:10:00Z' },
      { id: '3', game_type: 'tile_puzzle', score: 850, reaction_time_ms: 1450, accuracy: 0.88, dda_level_applied: 3, created_at: '2026-09-01T11:15:00Z' },
      { id: '4', game_type: 'word_association', score: 900, reaction_time_ms: 1100, accuracy: 0.92, dda_level_applied: 3, created_at: '2026-08-31T16:45:00Z' },
      { id: '5', game_type: 'pattern_sequence', score: 790, reaction_time_ms: 1520, accuracy: 0.84, dda_level_applied: 2, created_at: '2026-08-31T14:00:00Z' },
      { id: '6', game_type: 'color_stroop', score: 940, reaction_time_ms: 980, accuracy: 0.96, dda_level_applied: 4, created_at: '2026-08-31T10:00:00Z' },
    ];
  },

  async fetchMemoryCapsules(): Promise<MemoryCapsule[]> {
    return [
      { id: 'm1', title: 'Kaziranga Trip with Grandkids', description: 'Memorable wildlife safari in 2024 seeing the one-horned rhino.', category: 'travel', created_at: '2026-08-15', tag_count: 8 },
      { id: 'm2', title: 'Grandson Aarav 1st Birthday', description: 'Celebration at Guwahati family home with all relatives.', category: 'milestone', created_at: '2026-07-20', tag_count: 12 },
      { id: 'm3', title: 'Bihu Festival Dance 1985', description: 'Traditional spring festival memories in Tezpur.', category: 'childhood', created_at: '2026-06-10', tag_count: 5 },
      { id: 'm4', title: 'Family Garden Harvest', description: 'Fresh tea leaves and organic vegetables harvested with sister.', category: 'family', created_at: '2026-08-28', tag_count: 4 },
    ];
  },

  async fetchRoutines(): Promise<RoutineTask[]> {
    return [
      { id: 'r1', title: 'Morning Hydration & Herbal Tea', time: '07:30 AM', category: 'medication', is_completed: true },
      { id: 'r2', title: 'Cognitive Memory Matrix Session', time: '09:00 AM', category: 'memory', is_completed: true },
      { id: 'r3', title: 'Afternoon Prescription Medicine', time: '01:30 PM', category: 'medication', is_completed: false },
      { id: 'r4', title: 'Evening Walk in Community Park', time: '05:30 PM', category: 'exercise', is_completed: false },
      { id: 'r5', title: 'Family Video Call with Aarav', time: '07:00 PM', category: 'social', is_completed: false },
    ];
  }
};
